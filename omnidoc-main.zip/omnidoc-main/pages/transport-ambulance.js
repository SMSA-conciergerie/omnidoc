import { useEffect, useRef } from "react";
import Head from "next/head";
import dynamic from "next/dynamic";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function TransportAmbulance({ styles }) {
  gsap.registerPlugin(SplitText);
  const transportambTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(transportambTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(transportambTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>transport Ambulance - Omnidoc santé</title>
        <link
          href="https://www.omnidoc.ma/transport-ambulance"
          rel="canonical"
        />{" "}
        <meta
          name="viewport"
          content="user-scalable=no, width=device-width, initial-scale=1, maximum-scale=1"
        />
        <meta name="description" content="transport ambulance" />
        <meta
          name="keywords"
          content="ambulance urgence,ambulance Casablanca,ambulance Agadir,ambulance Rabat,ambulance Marrakesh,ambulance Tanger,ambulance Fes,SOS Médecins à Domicile Casablanca"
        />
        <meta property="og:title" content="transport Ambulance - Omnidoc" />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/transport-ambulance"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="transport Ambulance, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="transport Ambulance" />
      </Head>
      <div className={styles._trsptAmbulance_compo}>
        <div className={styles._trsptAmbulance}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._trsptAmbulance_title}>
            <h1 ref={transportambTitle}>Transport Ambulance</h1>
          </div>
        </div>
        <div className={styles._trsptAmbulance_content}>
          <div className={styles._trsptAmbulance_content_each}>
            <div>
              <h2>
                Transport en ambulance, faites confiance à nos ambulanciers.
              </h2>
            </div>
            <div>
              <p>
                Vous avez besoin d&apos;une ambulance en urgence ? vous avez un
                rendez-vous médical ponctuel ou régulier ? Pour votre
                tranquillité d&apos;esprit et celle de vos proches, notre flotte
                d&apos;ambulance est à votre disposition afin de vous conduire
                en toute sécurité et rapidité au lieu de votre choix.
              </p>
            </div>
          </div>
          <div className={styles._trsptAmbulance_content_each}>
            <div>
              <h2>
                Prise en charge par nos ambulances pour vos consultations et
                transferts.
              </h2>
            </div>
            <div>
              <p>
                Vous avez un rendez-vous médical, mais vous n’êtes pas en mesure
                de conduire ? Votre santé vous impose la position semi-allongée
                ou allongée pour plus de confort ? Vous avez besoin de
                transférer votre patient dans un autre établissement médical
                pour un traitement spécifique ? Autant de situations pour
                lesquelles les ambulanciers de notre groupe se tiennent à votre
                disposition <b>24h/24 et 7j/7</b>.<br /> Afin de vous conduire à
                vos rendez-vous médicaux, pour une hospitalisation ou encore
                pour un transfert inter-hospitalier, nous nous occupons de tout.
              </p>
            </div>
          </div>
          <div className={styles._trsptAmbulance_content_each}>
            <div>
              <h2>Des ambulances équipées pour les interventions d’urgence.</h2>
            </div>
            <div>
              <p>
                Nos ambulanciers, formés et maîtrisant parfaitement les gestes
                inhérents à leur métier (brancardage, gestes d’urgence et normes
                sanitaires et d’hygiène), sont en mesure de réaliser des
                transports sanitaires d’urgence en toute sécurité. Les
                ambulances sont équipées de tout le matériel médical nécessaire.
                Elles sont climatisées et quotidiennement contrôlées afin
                d’assurer au patient un trajet confortable et sécurisé. Nous
                disposons d’une très large flotte de véhicules de transport :
                VSL (véhicule sanitaire léger), ambulance simple, ambulance
                médicalisée, ambulance avec couveuse et de bloc mobile de
                réanimation.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default TransportAmbulance;
