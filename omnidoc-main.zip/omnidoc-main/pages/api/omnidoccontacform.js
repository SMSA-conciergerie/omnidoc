const nodemailer = require("nodemailer");
const handlebars = require("handlebars");
const fs = require("fs");
const path = require("path");
require("dotenv").config();
export default async (req, res) => {
  if (req.method === "POST") {
    const getDate = new Date()
    const date =
    getDate.toISOString().substring(0, 10) +
      " " +
      "a" +
      " " +
      getDate.toISOString().substring(11, 20);
    try {
      const filePath = path.join(
        process.cwd(),
        `/public/conatctEmailTemplate.hbs`
      );
      const emailTemplateSource = fs.readFileSync(filePath, "utf8");
     
      const { Nom, Prénom, Télé, AdresseMail, Message } = req.body;
      let transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        service: "gmail",
        port: 465,
        secure: true,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASSWORD,
        },
        tls: {
          rejectUnauthorized: false,
        },
      });
      const template = handlebars.compile(emailTemplateSource);
      const htmlToSend = template({
        date: date,
        Nom: Nom,
        Prenom: Prénom,
        Tele: Télé,
        AdresseMail: AdresseMail,
        Message: Message,
      });
      let mailOptions = {
        from: AdresseMail,
        to: process.env.SMTP_USER,
        subject: "contact omnidoc.ma",
        html: htmlToSend,
      };
      transporter.sendMail(mailOptions, function (error, response) {
        if (error) {
          console.log(error);
          callback(error);
        }
      });
      return res.status(202).json("Email sent successfully");
    } catch (error) {
      console.log(error);
    }
  }
};
