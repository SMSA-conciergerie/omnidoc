import client, { previewClient } from "../../lib/sanity";
const Comment = async (req, res) => {
  const { method } = req;
  const { name, email, _id } = req.body;
  var text = req.body.commentText;
  var stars = Number(req.body.stars);
  switch (method) {
    case "POST":
      try {
        await client
          .config({
            token: process.env.SANITY_API_TOKEN,
          })
          .create({
            _type: "comment",
            name,
            text,
            email,
            stars,
            blog: {
              _type: "reference",
              _ref: _id,
            },
          });
        return res
          .status(200)
          .json("le commentaire a été soumis avec succès...");
      } catch (error) {
        console.log(error);
      }
    default:
      break;
  }
};
const getUniquePosts = (posts) => {
  const slugs = new Set();
  return posts.filter((post) => {
    if (slugs.has(post.slug)) {
      return false;
    } else {
      slugs.add(post.slug);
      return true;
    }
  });
};
const postFields = `
  _id,
  name,
  title,
  text,
  'date': publishedAt,
`;

const getClient = (preview) => (preview ? previewClient : client);
export async function getPostAndMorePosts(slug, preview) {
  const curClient = getClient(preview);
  const [post, morePosts] = await Promise.all([
    curClient
      .fetch(
        `*[_type == "blog" && slug.current == $slug] | order(_updatedAt desc) {
        ${postFields}
        body,
        'comments': *[_type == "comment" && blog._ref == ^._id]{ name, email,stars, _createdAt,text}
      }`,
        { slug }
      )
      .then((res) => res?.[0]),
    curClient.fetch(
      `*[_type == "blog" && slug.current != $slug] | order(publishedAt desc, _updatedAt desc){
        ${postFields}
        body,
      }[0...2]`,
      { slug }
    ),
  ]);
  return { post, morePosts: getUniquePosts(morePosts) };
}
export default Comment;
