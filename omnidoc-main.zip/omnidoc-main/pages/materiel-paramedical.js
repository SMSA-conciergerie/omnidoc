import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
import { BsCheck2All } from "react-icons/bs";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function MedecinADomicile({ styles }) {
  gsap.registerPlugin(SplitText);
  const materialParaTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(materialParaTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });

    const splitParent = new SplitText(materialParaTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>Matériel Paramédical- Omnidoc santé</title>
        <link
          href="https://www.omnidoc.ma/materiel-paramedical"
          rel="canonical"
        />
        <meta
          name="keywords"
          content="
           SOS Médecin a domicile Fes,SOS Médecin a domicile Rabat,SOS Médecin a domicile Agadir,SOS Médecins à domicile Tanger,SOS Médecin a domicile Marrakech"
        />
        <meta
          name="description"
          content="matériel Paramédical, dans tous les villes de maroc"
        />
        <meta property="og:title" content="Matériel Paramédical- Omnidoc" />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/materiel-paramedical"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="matériel Paramédical, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="matériel Paramédical" />
      </Head>
      <div className={styles._materielParaMedical_compo}>
        <div className={styles._materielParaMedical}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._materielParaMedical_title}>
            <h1 ref={materialParaTitle}>Matériel Paramédical</h1>
          </div>
        </div>
        <div className={styles._materielParaMedical_compo_para}>
          <h5>Matériel paramédical pour particulier ou professionnel</h5>
          <p>
            Nous vous proposons à la location ou à la vente les meilleures
            solutions de matériel paramédical nécessaire aux soins, à la
            mobilité et à l&apos;hospitalisation à domicile. Parce que le
            confort et le bien-être des patients est notre priorité, nos équipes
            s'engagent à vous conseiller et à vous accompagner dans le choix
            d'un matériel paramédical adapté.
          </p>
        </div>
        <div className={styles._materielParaMedical_content}>
          <div className={styles._materielParaMedical_content_each}>
            <div>
              <h4>SERVICE PARAMEDICAL</h4>
            </div>
            <p>
              <span>
                <BsCheck2All />
              </span>
              Lit médical
            </p>
            <p>
              <span>
                <BsCheck2All />
              </span>
              Oxygène
            </p>
            <p>
              <span>
                <BsCheck2All />
              </span>
              Extracteur d’oxygène
            </p>
            <p>
              <span>
                <BsCheck2All />
              </span>
              Assistance respirateur
            </p>
            <p>
              <span>
                <BsCheck2All />
              </span>
              Seringue auto-poussante
            </p>
            <p>
              <span>
                <BsCheck2All />
              </span>
              Scope, monitoring
            </p>
            <p>
              <span>
                <BsCheck2All />
              </span>
              Matériel d’hospitalisation à domicile, etc.
            </p>
          </div>
          <div className={styles._materielParaMedical_content_each}>
            <div>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/materiel1_rE3UGoeIg.jpg?ik-sdk-version=javascript-1.4.3&updatedAt=1662551343344"
                loading="lazy"
                width="300"
                height="200"
                alt="omnidoc matériel paramédical"
              />
            </div>
            <div>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/materiel2_DMUJ2Wq2ax.jpg?ik-sdk-version=javascript-1.4.3&updatedAt=1662551343292"
                loading="lazy"
                width="300"
                height="200"
                alt="omnidoc matériel paramédical"
              />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default MedecinADomicile;
