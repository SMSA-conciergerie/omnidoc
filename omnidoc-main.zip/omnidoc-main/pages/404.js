import { useRef, useEffect } from "react";
import Link from "next/link";
import Head from "next/head";
import { useRouter } from "next/router";
function ErrorPage({ styles }) {
  const errorPage_compo = useRef(null);
  const router = useRouter();
  useEffect(() => {
    setTimeout(() => {
      return router.push("/");
    }, 1500);
  }, []);
  return (
    <div>
      <Head>
        <title>Omnidoc - 404</title>
      </Head>
      <div ref={errorPage_compo} className={styles.errorPage_compo}>
        <div className={styles._errorPage}>
          <div className={styles._errorPage_child}>
            <div className={styles._errorPage_child_container}>
              <div>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/404_0kIfFxrGe.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655307370410"
                  width="800"
                  height="500"
                  alt="omnidoc Page non trouvée"
                  title="omnidoc - Page non trouvée"
                />
              </div>
              <div>
                <Link href="/">
                  <a>
                    <button>À L'accueil</button>
                  </a>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ErrorPage;
