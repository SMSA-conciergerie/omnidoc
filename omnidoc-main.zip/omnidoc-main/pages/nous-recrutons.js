import Link from "next/link";
import UnderConstruction from "../components/Under_contsruction";
function WeAreHiring({ styles, underConstruction }) {
  return (
    <div>
      {underConstruction ? (
        <UnderConstruction />
      ) : (
        <div className={styles._hiring_compo}>
          <div className={styles._hiring}>
            <div className={styles._hiring_nav}>
              <div>
                <Link href="/">
                  <a>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
                      width="100"
                      height="80"
                      loading="lazy"
                      alt="omnidoc logo, omnidoc"
                    />
                  </a>
                </Link>
              </div>
              <div>
                <ul>
                  <li>
                    <Link href="/">
                      <a>Accueil</a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/gallery">
                      <a>Gallery</a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact">
                      <a>Contact</a>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className={styles._hiring_child}>
              <div className={styles._hiring_child_content}>
                <div>
                  <h1>
                    Nous
                    <br />
                    recrutons.
                  </h1>
                </div>
                <div>
                  <p>
                    At vero eos et accusamus et iusto odio dignissimos ducimus
                    qui blanditiis praesentium voluptatum deleniti atque
                    corrupti quos dolores et quas occaecati cupiditate non
                    provident, similique sunt in culpa qui officia deserunt
                    mollitia animi, id est laborum et dolorum fuga
                  </p>
                </div>
                <div>
                  <button>Rejoignez-nous</button>
                </div>
              </div>
              <div>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/hiring_AByV6myue.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1657834101462"
                  width="400"
                  height="400"
                  loading="lazy"
                  alt="omnidoc recrutement"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default WeAreHiring;
