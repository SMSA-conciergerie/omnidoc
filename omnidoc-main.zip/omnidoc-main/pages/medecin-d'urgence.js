import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function Urgence({ styles }) {
  gsap.registerPlugin(SplitText);
  const medcineadomicileTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(medcineadomicileTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });

    const splitParent = new SplitText(medcineadomicileTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>médecin d'urgence - Omnidoc santé</title>
        <link href="https://www.omnidoc.ma/medecin-d'urgence" rel="canonical" />
        <meta
          name="keywords"
          content="
                 SOS Médecin d'urgence Fes,SOS Médecin d'urgence Rabat,SOS Médecin d'urgence Agadir,SOS Médecins à domicile Tanger,SOS Médecin d'urgence Marrakech"
        />
        <meta
          name="description"
          content="médecin d'urgence, dans tous les villes de maroc"
        />
        <meta property="og:title" content="médecin d'urgence - Omnidoc" />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/medecin-d'urgence"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="médecin d'urgence, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="médecin d'urgence" />
      </Head>
      <div className={styles._homedoctor_compo}>
        <div className={styles._homedoctor}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._homedoctor_title}>
            <h1 ref={medcineadomicileTitle}>Médecin D'urgence</h1>
          </div>
        </div>
        <div className={styles._homedoctor_content}>
          <div className={styles._homedoctor_content_each}>
            <div>
              <h2>Un médecin , où que vous soyez !.</h2>
            </div>
            <div>
              <p>
                Omnidoc santé envoi <b>immédiat</b> de médecin, pour des soins à
                domicile d&apos;urgence ou sur votre lieu de travail{" "}
                <b>24H/24 et 7j/7</b>. Nos médecins assurent un accompagnement
                médical vers une structure hospitalière de votre choix si le cas
                le nécessite.
              </p>
            </div>
          </div>
          <div className={styles._homedoctor_content_each}>
            <div>
              <h2>Consultation à domicile ou selon le lieu de votre choix.</h2>
            </div>
            <div>
              <p>
                Omni Doc Santé met à votre disposition ses médecins et des
                services médicaux de très hautes qualité sur simple appel ou
                clic. Toute les consultations sont assurées par des médecins
                expérimentés.
              </p>
            </div>
          </div>
          <div className={styles._homedoctor_content_each}>
            <div>
              <h2>Un médecin en téléconsultation, où que vous soyez !.</h2>
            </div>
            <div>
              <p>
                Parlez à un médecin en vidéo 7 jours sur 7 depuis votre
                ordinateur ou votre smartphone, à l’horaire et avec la
                spécialité de votre choix. Nos médecins sont connectés à toute
                heure de la journée, pouvant répondre à l’ensemble de vos
                demandes.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default Urgence;
