import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import ImageUrlBuilder from "@sanity/image-url";
import BlockContent from "@sanity/block-content-to-react";
import Link from "next/link";
import Head from "next/head";
import Girl_With_Books from "../../public/girl-with-books.json";
import Lottie from "lottie-web";
import { AiOutlineComment } from "react-icons/ai";
const Newsletter = dynamic(() => import("../../components/Newsletter"), {
  ssr: true,
});
const Footer = dynamic(() => import("../../components/Footer"));
function index({ styles, data }) {
  const bookContainer = useRef(null);
  const blogPosts = useRef(null);
  useEffect(() => {
    Lottie.loadAnimation({
      container: bookContainer.current,
      renderer: "svg",
      loop: false,
      autoplay: true,
      animationData: Girl_With_Books,
    });
    Lottie.setSpeed(0.4);
    return () => {
      Lottie.destroy();
    };
  }, []);
  const imagebuilder = ImageUrlBuilder({
    projectId: "n5003uz7",
    dataset: "production",
  });
  return (
    <div>
      <Head>
        <title>omnidoc blog - omnidoc santé</title>
        <link href="https://www.omnidoc.ma/blog" rel="canonical" />
        <meta property="og:title" content="omnidoc blog" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.omnidoc.ma/blog" />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta property="og:description" content="omnidoc santé blog" />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="Accueil" />
        <meta name="description" content="omnidoc santé blog" />
        <link
          href="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
          rel="icon"
        />
        <meta name="keywords" content="omnidoc santé blog" />
      </Head>
      <div className={styles._blog}>
        <div className={styles._blog_child}>
          <div>
            <h1>
              Omnidoc<span>.Blog</span>
              <i className={styles._lottie_book} ref={bookContainer}></i>
            </h1>
          </div>
          <div className={styles._blog_child_bookMobile}>
            <img
              src="https://ik.imagekit.io/b85fe6mtm/Blog_N7rqso4nv.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1662215319047"
              width="300"
              height="300"
              alt="omnidoc santé blog"
              title="omnidoc santé blog"
            />
          </div>
          <div>
            <p>Pour En Savoir Plus Sur Votre Santé.</p>
          </div>
        </div>
        <div className={styles._blog_liner}></div>
        <div className={styles._blog_ContentHandler}>
          <h2 ref={blogPosts}>dernières nouvelles de notre blog...</h2>
          <div className={styles._blog_ContentHandler_child}>
            {data.map((post, i) => {
              return (
                <div
                  className={styles._blog_ContentHandler_child_eachPost}
                  key={i}
                >
                  <div
                    className={styles._blog_ContentHandler_child_eachPost_image}
                  >
                    <img
                      src={imagebuilder.image(post.image.asset._ref)}
                      alt={`omnidoc santé ${post.title}`}
                      title={`omnidoc santé ${post.title}`}
                    />
                  </div>
                  <div
                    className={
                      styles._blog_ContentHandler_child_eachPost_titleComment
                    }
                  >
                    <h3>{post.title}</h3>
                    <span>
                      <AiOutlineComment />
                    </span>
                  </div>
                  <div
                    className={
                      styles._blog_ContentHandler_child_eachPost_bodyText
                    }
                  >
                    <BlockContent blocks={post.body} />
                  </div>
                  <div
                    className={
                      styles._blog_ContentHandler_child_eachPost_urlndDate
                    }
                  >
                    <div>
                      <Link href={`/blog/${post.slug.current}`}>
                        <a>Lire la suite...</a>
                      </Link>
                    </div>
                    <span>{post._createdAt.substring(0, 10)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <Newsletter styles={styles} />
      <Footer />
    </div>
  );
}
export const getServerSideProps = async () => {
  const query = encodeURIComponent(`*[ _type == "blog"]`);
  const url = `https://n5003uz7.api.sanity.io/v1/data/query/production?query=${query}`;
  const result = await fetch(url).then((res) => res.json());
  if (!result) {
    return {
      notFound: true,
    };
  }
  return {
    props: {
      data: result.result,
    },
  };
};
export default index;
