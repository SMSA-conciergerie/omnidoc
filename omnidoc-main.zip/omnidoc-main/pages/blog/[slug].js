import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import { useRouter } from "next/router";
import ImageUrlBuilder from "@sanity/image-url";
import BlockContent from "@sanity/block-content-to-react";
import gsap, { Power3 } from "gsap";
import SplitText from "../../utils/Split3.min";
import { getPostAndMorePosts } from "../api/comments";
import { FiCheckCircle, FiShare } from "react-icons/fi";
import { MdDarkMode, MdOutlineDarkMode } from "react-icons/md";
import {
  AiFillFacebook,
  AiFillLinkedin,
  AiFillTwitterCircle,
} from "react-icons/ai";
const CommentForm = dynamic(() => import("../../components/CommentForm"), {
  ssr: true,
});
const Comments_By_Post = dynamic(
  () => import("../../components/Comments_By_Post"),
  { ssr: true }
);
const Navbar = dynamic(() => import("../../components/Navbar"));
const Footer = dynamic(() => import("../../components/Footer"));
const Newsletter = dynamic(() => import("../../components/Newsletter"), {
  ssr: true,
});
function Post({ dataPost, styles, comments, dataAuthor }) {
  const [isDark, setIsDark] = useState(false);
  const [isShared, setIsShared] = useState(false);
  const [url, setUrl] = useState("");
  const router = useRouter();
  const imagebuilder = ImageUrlBuilder({
    projectId: "n5003uz7",
    dataset: "production",
  });
  gsap.registerPlugin(SplitText);
  const id = dataPost.map((post) => post._id);
  const blog_Image = useRef(null);
  const blog_Date = useRef(null);
  const blog_Title = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(blog_Title.current, {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(blog_Title.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    const tl = gsap.timeline();
    tl.fromTo(
      blog_Image.current,
      {
        opacity: 0,
        y: 20,
      },
      {
        opacity: 1,
        y: 0,
        duration: 2,
        ease: Power3.easeOut,
        scale: 1.1,
      }
    )
      .fromTo(
        blog_Date.current,
        {
          opacity: 0,
          width: "5%",
          y: 20,
        },
        {
          opacity: 1,
          y: 0,
          width: "100%",
          duration: 2,
          ease: Power3.easeOut,
          scale: 1.1,
        },
        1
      )
      .to(
        splitServ.lines,
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          ease: Power3.easeOut,
          duration: 2,
        },
        0.8
      );
    setUrl(window.location);
  }, []);

  const handleIsSharedChanges = () => {
    setIsShared(true);
    setTimeout(() => {
      setIsShared(false);
    }, 2000);
  };
  return (
    <div>
      <style jsx global>
        {`
          body {
            background: ${isDark ? "#000" : null};
          }
          h3 {
            color: ${isDark ? "#fff" : null};
          }
          span,
          i {
            color: ${isDark ? "#fff" : null};
          }
        `}
      </style>
      <Head>
        <title>omnidoc santé blog</title>
        <link
          href={`https://www.omnidoc.ma/${router.query.slug}`}
          rel="canonical"
        />
        <meta
          property="og:title"
          content={`omnidoc blog ${router.query.slug}`}
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`omnidoc blog ${router.query.slug}`} />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content={`omnidoc blog ${router.query.slug}`}
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="Accueil" />
        <meta
          name="description"
          content={`omnidoc blog ${router.query.slug}`}
        />
        <link
          href="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
          rel="icon"
        />
        <meta name="keywords" content={`omnidoc blog ${router.query.slug}`} />
      </Head>
      <Navbar />
      {isShared ? (
        <div className={styles._isSharedModale}>
          <p>
            <span>
              <FiCheckCircle />
            </span>
            Le lien est prêt à être partagé...
          </p>
        </div>
      ) : null}
      <div className={styles._blogPosts}>
        <div className={styles._blogPosts_child}>
          {dataPost.map((post, i) => {
            return (
              <div className={styles._blogPosts_child_eachPost} key={i}>
                <div className={styles._blogPosts_child_eachPost_image}>
                  <img
                    ref={blog_Image}
                    src={imagebuilder.image(post.image.asset._ref)}
                    alt={`omnidoc santé ${post.title}`}
                    title={`omnidoc santé ${post.title}`}
                  />
                </div>
                <div className={styles._blogPosts_child_eachPost_icons}>
                  <span
                    onClick={() => {
                      handleIsSharedChanges();
                    }}
                  >
                    <FiShare />
                  </span>
                  <i
                    onClick={() => {
                      setIsDark(!isDark);
                    }}
                  >
                    {isDark ? <MdOutlineDarkMode /> : <MdDarkMode />}
                  </i>
                </div>
                <div className={styles._blogPosts_child_eachPost_datendtime}>
                  <span ref={blog_Date}>
                    Publie le {post._createdAt.substring(0, 10)}{" "}
                    {post._createdAt.substring(11, 16)}
                  </span>
                </div>
                <div className={styles._blogPosts_child_eachPost_shares}>
                  <div
                    className={styles._blogPosts_child_eachPost_shares_child}
                  >
                    <a
                      href={`https://www.facebook.com/sharer/sharer.php?u=${url}`}
                      target="_blank"
                      className={
                        styles._blogPosts_child_eachPost_shares_child_fb
                      }
                    >
                      <span>
                        <AiFillFacebook />
                      </span>
                      Partager
                    </a>
                    <a
                      href={`https://twitter.com/share?url=${url}`}
                      target="_blank"
                      className={
                        styles._blogPosts_child_eachPost_shares_child_tw
                      }
                    >
                      <span>
                        <AiFillTwitterCircle />
                      </span>
                      Partager
                    </a>
                    <a
                      href={`https://www.linkedin.com/sharing/share-offsite/?url=${url}`}
                      target="_blank"
                      className={
                        styles._blogPosts_child_eachPost_shares_child_linkd
                      }
                    >
                      <span>
                        <AiFillLinkedin />
                      </span>
                      Partager
                    </a>
                  </div>
                </div>
                <div>
                  <h3 ref={blog_Title}>{post.title}</h3>
                </div>
                <div className={styles._blogPosts_child_eachPost_bodyText}>
                  <BlockContent blocks={post.body} />
                </div>
              </div>
            );
          })}
          <div className={styles._blogPosts_child_author_info}>
            <div>
              <img
                src={imagebuilder.image(dataAuthor.author.image.asset._ref)}
                alt="omnidoc blog auteure"
                title="omnidoc blog auteure"
              />
              <h6>Article Par : {dataAuthor.author.name}.</h6>
            </div>
          </div>
        </div>
        <CommentForm styles={styles} _id={id} isDark={isDark} />
        {comments.length <= 0 ? null : (
          <Comments_By_Post
            styles={styles}
            comments={comments}
            isDark={isDark}
          />
        )}
        <Newsletter styles={styles} isDark={isDark} />
      </div>
      <Footer isDark={isDark} />
    </div>
  );
}

export const getServerSideProps = async (pageContext) => {
  const pageSlug = pageContext.query.slug;
  const postComments = await getPostAndMorePosts(pageSlug, pageSlug);
  const postCommentsData = postComments.post;
  const { comments } = postCommentsData;
  if (!comments) {
    console.log("no commentaire");
  }
  if (!pageSlug) {
    return {
      notFound: true,
    };
  }

  const query = encodeURIComponent(
    `*[ _type == "blog" && slug.current == "${pageSlug}" ]`
  );
  const queryAuthor = encodeURIComponent(
    `*[ _type == "blog" && slug.current == "${pageSlug}" ] {
      author-> {
        name,
        image
      }
    }`
  );
  const urlAuthor = `https://n5003uz7.api.sanity.io/v1/data/query/production?query=${queryAuthor}`;
  const url = `https://n5003uz7.api.sanity.io/v1/data/query/production?query=${query}`;
  const resultAuthor = await fetch(urlAuthor).then((res) => res.json());
  const result = await fetch(url).then((res) => res.json());
  const data = result.result[0];
  const dataPost = [data];
  const dataAuthor = resultAuthor.result[0];
  if (!data) {
    return {
      notFound: true,
    };
  } else {
    return {
      props: {
        dataPost,
        comments,
        dataAuthor,
      },
    };
  }
};
export default Post;
