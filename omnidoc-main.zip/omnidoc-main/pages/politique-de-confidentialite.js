import { useEffect, useRef } from "react";
import Head from "next/head";
import dynamic from "next/dynamic";
import Link from "next/link";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function PrivacyPolicy({ styles }) {
  gsap.registerPlugin(SplitText);
  const politiqueTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(politiqueTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(politiqueTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>politique de confidentialité - Omnidoc santé</title>
        <meta
          name="keywords"
          content="omnidoc politique de confidentialité, ambulance onmidoc casablanca"
        />
        <link
          href="https://www.omnidoc.ma/politique-de-confidentialite"
          rel="canonical"
        />
        <meta name="description" content="politique de confidentialité" />
        <meta
          property="og:title"
          content="politique de confidentialité - Omnidoc santé"
        />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/politique-de-confidentialite"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="politique de confidentialité"
        />
        <meta name="twitter:card" content="summary" />
        <meta
          name="twitter:text:title"
          content="politique de confidentialité"
        />
      </Head>
      <div className={styles._privacyPolicy}>
        <div className={styles._privacyPolicy_nav}>
          <Navbar />
        </div>
        <div className={styles._privacyPolicy_title}>
          <h1 ref={politiqueTitle}>Politique de confidentialité</h1>
        </div>
      </div>
      <div className={styles._privacyPolicy_Child}>
        <div className={styles._privacyPolicy_Child_content}>
          <p>1. Introduction</p>
          <p>Bienvenue chez omnidoc LLC.</p>
          <p>
            omnidoc LLC ("nous", "notre") exploits{" "}
            <Link href="https://www.omnidoc.ma/">
              <a>https://www.omnidoc.ma/</a>
            </Link>
            (ci-après dénommé "Service").
          </p>
          <p>
            Notre politique de confidentialité régit votre visite sur
            <Link href="https://www.omnidoc.ma/">
              <a>https://www.omnidoc.ma/</a>
            </Link>
            ,et explique comment nous recueillons, protégeons et divulguons les
            informations résultant de votre utilisation de notre Service.
          </p>
          <p>
            Nous utilisons vos données pour fournir et améliorer le Service. En
            utilisant le Service, vous acceptez la collecte et l'utilisation des
            informations conformément à cette politique. Sauf indication
            contraire dans la présente politique de confidentialité, les termes
            utilisés dans la présente politique de confidentialité ont la même
            signification que dans nos conditions générales.
          </p>
          <p>
            Nos conditions générales ("Conditions") régissent toute utilisation
            de notre service et, avec la politique de confidentialité,
            constituent votre accord avec nous ("accord").
          </p>
          <p>2. Définitions</p>
          <p>
            SERVICE désigne le site Web{" "}
            <Link href="https://www.omnidoc.ma/">
              <a>https://www.omnidoc.ma/</a>
            </Link>{" "}
            exploité par omnidoc LLC.
          </p>
          <p>
            Les DONNÉES PERSONNELLES désignent les données concernant une
            personne vivante qui peuvent être identifiées à partir de ces
            données (ou de celles-ci et d'autres informations en notre
            possession ou susceptibles d'entrer en notre possession).
          </p>
          <p>
            Les DONNÉES D'UTILISATION sont des données collectées
            automatiquement générées par l'utilisation du Service ou à partir de
            l'infrastructure du Service elle-même (par exemple, la durée d'une
            visite de page).
          </p>
          <p>
            Les COOKIES sont de petits fichiers stockés sur votre appareil
            (ordinateur ou appareil mobile).
          </p>
          <p>
            CONTRÔLEUR DE DONNÉES désigne une personne physique ou morale qui
            (seule ou conjointement ou en commun avec d'autres personnes)
            détermine les finalités pour lesquelles et la manière dont les
            données personnelles sont ou doivent être traitées. Aux fins de la
            présente politique de confidentialité, nous sommes un contrôleur de
            données de vos données.
          </p>
          <p>
            LES PROCESSEURS DE DONNÉES (OU PRESTATAIRES DE SERVICES) désignent
            toute personne physique ou morale qui traite les données pour le
            compte du Responsable du traitement. Nous pouvons utiliser les
            services de divers fournisseurs de services afin de traiter vos
            données plus efficacement.
          </p>{" "}
          <p>
            La personne concernée est toute personne physique faisant l'objet de
            données personnelles.
          </p>
          <p>
            L'UTILISATEUR est la personne qui utilise notre Service.
            L'Utilisateur correspond à la Personne Concernée, qui fait l'objet
            des Données Personnelles.
          </p>
          <p>3. Collecte et utilisation des informations</p>
          <p>
            Nous collectons différents types d'informations à diverses fins pour
            vous fournir et améliorer notre service.
          </p>
          <p>4. Types de données collectées</p>
          <p>Données personnelles</p>
          <p>
            Lors de l'utilisation de notre Service, nous pouvons vous demander
            de nous fournir certaines informations personnellement identifiables
            qui peuvent être utilisées pour vous contacter ou vous identifier
            ("Données personnelles"). Les informations personnellement
            identifiables peuvent inclure, mais sans s'y limiter :
          </p>
          <p>0.1. Email address</p>
          <p>0.2. Prénom et nom</p>
          <p>0.3. Numéro de téléphone</p>
          <p>0.4. Adresse, Pays, État, Province, Code ZIP/Postal, Ville</p>
          <p>0.5. Cookies et données d'utilisation</p>
          <p>
            Nous pouvons utiliser vos données personnelles pour vous contacter
            avec des newsletters, du matériel marketing ou promotionnel et
            d'autres informations susceptibles de vous intéresser. Vous pouvez
            refuser de recevoir tout ou partie de ces communications de notre
            part en suivant le lien de désabonnement.
          </p>
          <p>Données d'utilisation</p>
          <p>
            Nous pouvons également collecter des informations que votre
            navigateur envoie chaque fois que vous visitez notre Service ou
            lorsque vous accédez au Service par ou via n'importe quel appareil
            ("Données d'utilisation").
          </p>
          <p>
            Ces données d'utilisation peuvent inclure des informations telles
            que l'adresse de protocole Internet de votre ordinateur (par
            exemple, l'adresse IP), le type de navigateur, la version du
            navigateur, les pages de notre service que vous visitez, l'heure et
            la date de votre visite, le temps passé sur ces pages, les
            identificateurs d'appareil et autres données de diagnostic.
          </p>
          <p>
            Lorsque vous accédez au Service avec un appareil, ces données
            d'utilisation peuvent inclure des informations telles que le type
            d'appareil que vous utilisez, l'identifiant unique de votre
            appareil, l'adresse IP de votre appareil, le système d'exploitation
            de votre appareil, le type de navigateur Internet que vous utilisez,
            l'appareil unique identifiants et autres données de diagnostic.
          </p>
          <p>Suivi des données des cookies</p>
          <p>
            Nous utilisons des cookies et des technologies de suivi similaires
            pour suivre l'activité sur notre Service et nous détenons certaines
            informations.
          </p>
          <p>
            Les cookies sont des fichiers contenant une petite quantité de
            données qui peuvent inclure un identifiant unique anonyme. Les
            cookies sont envoyés à votre navigateur à partir d'un site Web et
            stockés sur votre appareil. D'autres technologies de suivi sont
            également utilisées telles que les balises, les balises et les
            scripts pour collecter et suivre les informations et pour améliorer
            et analyser notre Service.
          </p>
          <p>
            Vous pouvez demander à votre navigateur de refuser tous les cookies
            ou d'indiquer quand un cookie est envoyé. Cependant, si vous
            n'acceptez pas les cookies, vous ne pourrez peut-être pas utiliser
            certaines parties de notre Service.
          </p>
          <p>Exemples de Cookies que nous utilisons :</p>
          <p>
            0.1. Cookies de session : Nous utilisons des cookies de session pour
            faire fonctionner notre Service.
          </p>
          <p>
            0.2. Cookies de préférence : Nous utilisons des cookies de
            préférence pour mémoriser vos préférences et divers paramètres.
          </p>
          <p>
            0.3. Cookies de sécurité : Nous utilisons des cookies de sécurité à
            des fins de sécurité.
          </p>
          <p>
            0.4. Cookies publicitaires : les cookies publicitaires sont utilisés
            pour vous proposer des publicités qui peuvent être pertinentes pour
            vous et vos intérêts..
          </p>
          <p>Autre informations</p>
          <p>
            Lors de l'utilisation de notre Service, nous pouvons également
            collecter les informations suivantes : sexe, âge, date de naissance,
            lieu de naissance, détails du passeport, nationalité, enregistrement
            au lieu de résidence et adresse réelle, numéro de téléphone
            (travail, mobile), détails des documents sur l'éducation, la
            qualification, la formation professionnelle, les contrats de
            travail, les{" "}
            <a href="https://policymaker.io/non-disclosure-agreement/">
              accords NDA
            </a>
            , les informations sur les primes et la rémunération, les
            informations sur l'état civil, membres de la famille, numéro de
            sécurité sociale (ou autre numéro d'identification fiscale),
            emplacement du bureau et autres données.
          </p>
          <p>5. Utilisation des données</p>
          <p>omnidoc LLC utilise les données collectées à diverses fins :</p>
          <p>0.1. fournir et maintenir notre service</p>
          <p>0.2. Pour vous avertir des changements de notre service</p>
          <p>
            0.3. pour vous permettre de participer aux fonctionnalités
            interactives de notre Service lorsque vous choisissez de le faire
          </p>
          <p>0.4. fournir un support client</p>
          <p>
            0.5. pour recueillir des analyses ou des informations précieuses
            afin que nous puissions améliorer notre service
          </p>
          <p>0.6. pour surveiller l'utilisation de notre service</p>
          <p>
            0.7. pour détecter, prévenir et résoudre les problèmes techniques
          </p>
          <p>
            0.8. pour remplir tout autre objectif pour lequel vous le fournissez
          </p>
          <p>
            0.9. pour exécuter nos obligations et faire valoir nos droits
            découlant de tout contrat conclu entre vous et nous, y compris pour
            la facturation et le recouvrement
          </p>
          <p>
            0.10. pour vous fournir des avis concernant votre compte et/ou votre
            abonnement, y compris des avis d'expiration et de renouvellement,
            des instructions par e-mail, etc.
          </p>
          <p>
            0.11. pour vous fournir des actualités, des offres spéciales et des
            informations générales sur d'autres biens, services et événements
            que nous proposons et qui sont similaires à ceux que vous avez déjà
            achetés ou demandés, sauf si vous avez choisi de ne pas recevoir ces
            informations
          </p>
          <p>
            0.12. de toute autre manière que nous pouvons décrire lorsque vous
            fournissez les informations
          </p>
          <p>0.13. à toute autre fin avec votre consentement.</p>
          <p>6. Conservation des données</p>
          <p>
            Nous ne conserverons vos données personnelles que le temps
            nécessaire aux fins énoncées dans la présente politique de
            confidentialité. Nous conserverons et utiliserons vos données
            personnelles dans la mesure nécessaire pour nous conformer à nos
            obligations légales (par exemple, si nous sommes tenus de conserver
            vos données pour nous conformer aux lois applicables), résoudre les
            litiges et appliquer nos accords et politiques juridiques.
          </p>
          <p>
            Nous conserverons également les données d'utilisation à des fins
            d'analyse interne. Les données d'utilisation sont généralement
            conservées pendant une période plus courte, sauf lorsque ces données
            sont utilisées pour renforcer la sécurité ou pour améliorer la
            fonctionnalité de notre service, ou lorsque nous sommes légalement
            tenus de conserver ces données pendant des périodes plus longues.
          </p>
          <p>7. Transfert de données</p>
          <p>
            Vos informations, y compris les données personnelles, peuvent être
            transférées et conservées sur des ordinateurs situés en dehors de
            votre état, province, pays ou autre juridiction gouvernementale où
            les lois sur la protection des données peuvent différer de celles de
            votre juridiction.
          </p>
          <p>
            Si vous vous trouvez en dehors du Maroc et que vous choisissez de
            nous fournir des informations, veuillez noter que nous transférons
            les données, y compris les données personnelles, au Maroc et que
            nous les traitons là-bas.
          </p>
          <p>
            Votre consentement à cette politique de confidentialité suivi de
            votre soumission de ces informations représente votre accord à ce
            transfert.
          </p>
          <p>
            omnidoc LLC prendra toutes les mesures raisonnablement nécessaires
            pour s'assurer que vos données sont traitées en toute sécurité et
            conformément à la présente politique de confidentialité et aucun
            transfert de vos données personnelles n'aura lieu vers une
            organisation ou un pays à moins qu'il n'y ait des contrôles adéquats
            en place, y compris la sécurité de vos données et autres
            informations personnelles.
          </p>
          <p>8. Divulgation des données</p>
          <p>
            Nous pouvons divulguer les informations personnelles que nous
            collectons ou que vous fournissez :
          </p>
          <p>0.1. Transaction d'affaires.</p>
          <p>
            Si nous ou nos filiales sommes impliqués dans une fusion, une
            acquisition ou une vente d'actifs, vos données personnelles peuvent
            être transférées.
          </p>
          <p>
            0.2. Autres cas. Nous pouvons également divulguer vos informations :
          </p>
          <p>0.2.1. à nos filiales et sociétés affiliées</p>
          <p>
            0.2.2. aux sous-traitants, prestataires de services et autres tiers
            que nous utiliser pour soutenir notre entreprise
          </p>
          <p>0.2.3. pour atteindre l'objectif pour lequel vous le fournissez</p>
          <p>
            0.2.4. dans le but d'inclure le logo de votre entreprise sur nos
            site Internet
          </p>
          <p>
            0.2.5.à toute autre fin divulguée par nous lorsque vous fournissez
            le informations
          </p>
          <p>0.2.6. avec votre consentement dans tous les autres cas</p>
          <p>
            0.2.7. si nous estimons que la divulgation est nécessaire ou
            appropriée pour protéger les droits, la propriété ou la sécurité de
            la Société, nos clients ou autres.
          </p>
          <p>9. Sécurité des données</p>
          <p>
            La sécurité de vos données est importante pour nous, mais
            rappelez-vous qu'aucun méthode de transmission sur Internet ou
            méthode de transmission électronique le stockage est 100% sécurisé.
            Alors que nous nous efforçons d'utiliser commercialement moyens
            acceptables pour protéger vos données personnelles, nous ne pouvons
            garantir sa sécurité absolue.
          </p>
          <p>
            10. Vos droits en matière de protection des données dans le cadre de
            la protection générale des données Réglementation (RGPD)
          </p>
          <p>
            Si vous êtes un résident de l'Union européenne (UE) et de l'Union
            européenne Espace économique (EEE), vous disposez de certains droits
            en matière de protection des données, couverts par le RGPD.
          </p>
          <p>
            Nous visons à prendre des mesures raisonnables pour vous permettre
            de corriger, modifier, supprimer ou limiter l'utilisation de vos
            données personnelles.
          </p>
          <p>
            {" "}
            Si vous souhaitez être informé des données personnelles que nous
            détenons à votre sujet et si vous souhaitez qu'il soit supprimé de
            nos systèmes, veuillez nous envoyer un e-mail à
            <Link href="mailto:contact@omnidoc.ma">
              <a>contact@omnidoc.ma.</a>
            </Link>
          </p>
          <p>
            Dans certaines circonstances, vous disposez de la protection des
            données suivante droits:
          </p>
          <p>
            0.1. le droit d'accéder, de mettre à jour ou de supprimer les
            informations que nous avoir sur toi
          </p>
          <p>
            0.2. le droit de rectification. Vous avez le droit d'avoir votre
            informations rectifiées si ces informations sont inexactes ou
            incomplet
          </p>
          <p>
            0.3. le droit de s'opposer. Vous avez le droit de vous opposer à
            notre traitement de vos Données Personnelles
          </p>
          <p>
            0.4. le droit de restriction. Vous avez le droit de demander que
            nous limiter le traitement de vos informations personnelles
          </p>
          <p>
            0,5. le droit à la portabilité des données. Vous avez le droit
            d'être fourni une copie de vos données personnelles dans un format
            structuré, format lisible par machine et couramment utilisé
          </p>
          <p>
            0,6. le droit de retirer son consentement. Vous avez également le
            droit de retirer votre consentement à tout moment lorsque nous
            comptons sur votre consentement pour traiter vos informations
            personnelles
          </p>
          <p>
            Veuillez noter que nous pouvons vous demander de vérifier votre
            identité avant répondre à de telles demandes. Veuillez noter que
            nous ne pourrons peut-être pas fournir Service sans certaines
            données nécessaires.
          </p>
          <p>
            Vous avez le droit de porter plainte auprès d'une autorité de
            protection des données concernant notre collecte et utilisation de
            vos données personnelles. Pour plus d'informations, veuillez
            contacter votre autorité locale de protection des données dans
            l'Union européenne Espace économique (EEE).
          </p>
          <p>
            11. Vos droits de protection des données en vertu de la California
            Privacy Loi sur la protection (CalOPPA)
          </p>
          <p>
            CalOPPA est la première loi d'État du pays à exiger des sites Web et
            services en ligne pour afficher une politique de confidentialité.
            Les lois portée s'étend bien au-delà de la Californie pour exiger
            une personne ou entreprise aux États-Unis (et peut-être dans le
            monde) qui exploite des sites Web collectant des informations
            personnellement identifiables des consommateurs californiens à
            publier une politique de confidentialité visible sur son site Web
            indiquant exactement les informations collectées et les personnes
            avec lesquelles il est partagé, et de se conformer aux cette
            politique.
          </p>
          <p>Selon CalOPPA, nous convenons de ce qui suit :</p>
          <p>
            0.1. les utilisateurs peuvent visiter notre site de manière anonyme
          </p>
          <p>
            0.2. notre lien Politique de confidentialité inclut le mot
            « Confidentialité » et peut facilement repérable sur la page
            d'accueil de notre site
          </p>
          <p>
            0.3.les utilisateurs seront informés de tout changement de politique
            de confidentialité sur notre Politique de confidentialité
          </p>
          <p>
            0.4. les utilisateurs seront informés de tout changement de
            politique de confidentialité sur notre Politique de confidentialité
          </p>
          <p>Notre politique sur les signaux « Ne pas suivre » :</p>
          <p>
            Nous respectons les signaux Do Not Track et ne suivons pas,
            n'installons pas de cookies ou utiliser la publicité lorsqu'un
            mécanisme de navigateur Do Not Track est en place. Ne pas suivre est
            une préférence que vous pouvez définir dans votre navigateur Web
            pour informez les sites Web que vous ne souhaitez pas être suivi.
          </p>
          <p>
            Vous pouvez activer ou désactiver Do Not Track en visitant les
            Préférences ou la page Paramètres de votre navigateur Web.
          </p>
          <p>
            12. Vos droits de protection des données en vertu du California
            Consumer Loi sur la protection des renseignements personnels (CCPA)
          </p>
          <p>
            Si vous êtes un résident de Californie, vous avez le droit
            d'apprendre ce que les données que nous collectons à votre sujet,
            demander de supprimer vos données et de ne pas vendre (Partagez-le.
            Pour exercer vos droits de protection des données, vous pouvez faire
            certaines demandes et demandez-nous :
          </p>
          <p>
            0.1.Quelles informations personnelles nous avons sur vous. Si tu
            fais ça demande, nous vous retournerons :
          </p>
          <p>
            0.0.1.Les catégories d'informations personnelles que nous avons
            collectées au propos de vous.
          </p>
          <p>
            0.0.2. Les catégories de sources à partir desquelles nous
            recueillons vos données personnelles informations.
          </p>
          <p>
            0.0.3. Le but commercial ou commercial de la collecte ou de la vente
            Vos informations personnelles.
          </p>
          <p>
            0.0.4. Les catégories de tiers avec lesquels nous partageons des
            informations personnelles informations.
          </p>
          <p>
            0.0.5. Les informations personnelles spécifiques que nous avons
            collectées au propos de vous.
          </p>
          <p>
            0.0.6. Une liste des catégories d'informations personnelles que nous
            avons vendu, ainsi que la catégorie de toute autre société à
            laquelle nous l'avons vendu. Si nous n'avons pas vendu vos
            informations personnelles, nous vous informerons de ce fait.
          </p>
          <p>
            0.0.7. Une liste des catégories d'informations personnelles que nous
            avons divulgués à des fins commerciales, ainsi que la catégorie de
            tout autre société avec laquelle nous l'avons partagé.
          </p>
          <p>
            Veuillez noter que vous avez le droit de nous demander de vous
            fournir ce informations jusqu'à deux fois au cours d'une période de
            douze mois glissants. Lorsque vous faites cette demande, les
            informations fournies peuvent être limitées à les informations
            personnelles que nous avons collectées à votre sujet au cours des
            12 dernières mois.
          </p>
          <p>
            0.2. Pour supprimer vos informations personnelles. Si vous faites
            cette demande, nous supprimerons les informations personnelles que
            nous détenons à votre sujet à compter du date de votre demande à
            partir de nos dossiers et diriger tout service fournisseurs à faire
            de même. Dans certains cas, la suppression peut être grâce à la
            désidentification de l'information. Si vous choisissez de supprimer
            vos informations personnelles, vous ne pourrez peut-être pas
            utiliser certaines fonctions qui nécessitent vos informations
            personnelles pour fonctionner.
          </p>
          <p>
            0.3. Pour arrêter de vendre vos informations personnelles. Nous ne
            vendons ni louer vos informations personnelles à des tiers à quelque
            fin que ce soit. Nous ne vendons pas vos informations personnelles
            pour une contrepartie monétaire. Cependant, dans certaines
            circonstances, un transfert de informations à un tiers, ou au sein
            de notre famille de sociétés, sans contrepartie monétaire peut être
            considérée comme une « vente » en vertu de Loi californienne. Vous
            êtes le seul propriétaire de vos Données Personnelles et pouvez
            demander la divulgation ou la suppression à tout moment.
          </p>
          <p>
            Si vous soumettez une demande pour cesser de vendre vos informations
            personnelles, nous arrêterons de faire de tels transferts.
          </p>
          <p>
            Veuillez noter que si vous nous demandez de supprimer ou de cesser
            de vendre vos données, cela peut avoir un impact sur votre
            expérience avec nous, et vous ne pourrez peut-être pas participer à
            certains programmes ou services d'adhésion qui nécessitent
            l'utilisation de vos informations personnelles pour fonctionner.
            Mais en aucun circonstances, nous ferons de la discrimination contre
            vous pour avoir exercé votre droits.
          </p>
          <p>
            Pour exercer vos droits de protection des données en Californie
            décrits ci-dessus, merci d'adresser votre/vos demande(s) par mail :{" "}
            <Link href="mailto:contact@omnidoc.ma">
              <a>contact@omnidoc.ma.</a>
            </Link>
          </p>
          <p>
            Vos droits de protection des données, décrits ci-dessus, sont
            couverts par le CCPA, abréviation de California Consumer Privacy
            Act. Découvrir plus, visitez le site Web officiel d'information
            législative de la Californie. Le CCPA est entré en vigueur le
            01/01/2020.
          </p>
          <p>13. Les fournisseurs de services</p>
          <p>
            Nous pouvons faire appel à des sociétés tierces et à des
            particuliers pour faciliter notre Service ("Prestataires de
            services"), fournir le Service en notre nom, effectuer des services
            liés au service ou nous aider à analyser comment notre Le service
            est utilisé.
          </p>
          <p>
            Ces tiers n'ont accès à vos Données Personnelles que pour effectuer
            ces tâches en notre nom et sont tenus de ne pas divulguer ou
            l'utiliser à d'autres fins.
          </p>
          <p>14. Analytique</p>
          <p>
            Nous pouvons utiliser des fournisseurs de services tiers pour
            surveiller et analyser le l'utilisation de notre Service.
          </p>
          <p>15. Outils CI/CD</p>
          <p>
            Nous pouvons utiliser des fournisseurs de services tiers pour
            automatiser le développement processus de notre service.
          </p>
          <p>16. Remarketing comportemental</p>
          <p>
            Nous pouvons utiliser des services de remarketing pour faire de la
            publicité sur des sites Web tiers après votre visite sur notre
            Service. Nous et nos fournisseurs tiers utiliser des cookies pour
            informer, optimiser et diffuser des annonces en fonction de votre
            passé visites à notre Service.
          </p>
          <p>19.Modifications de cette politique de confidentialité</p>
          <p>
            Nous pouvons mettre à jour notre politique de confidentialité de
            temps à autre. Nous aviserons vous informer de tout changement en
            publiant la nouvelle politique de confidentialité sur cette page.
          </p>
          <p>
            Nous vous informerons par e-mail et/ou par un avis visible sur notre
            Service, avant que le changement ne devienne effectif et mis à jour
            "date d'entrée en vigueur" en haut de cette politique de
            confidentialité.
          </p>
          <p>
            Il vous est conseillé de consulter périodiquement cette politique de
            confidentialité pour toute changements. Les modifications apportées
            à cette politique de confidentialité entrent en vigueur lorsqu'elles
            sont publié sur cette page.
          </p>
          <p>20. Nous contacter </p>
          <p>
            Si vous avez des questions concernant cette politique de
            confidentialité, veuillez nous contacter par e-mail :{" "}
            <Link href="mailto:contact@omnidoc.ma">
              <a>contact@omnidoc.ma</a>
            </Link>
            .
          </p>
        </div>
      </div>
      <Newsletter styles={styles} />
      <Footer />
    </div>
  );
}

export default PrivacyPolicy;
