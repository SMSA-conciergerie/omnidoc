import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function MedecinADomicile({ styles }) {
  gsap.registerPlugin(SplitText);
  const medcineadomicileTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(medcineadomicileTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });

    const splitParent = new SplitText(medcineadomicileTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>médecin a domicile - Omnidoc santé</title>
        <link
          href="https://www.omnidoc.ma/medecin-a-domicile"
          rel="canonical"
        />
        <meta
          name="keywords"
          content="
           SOS Médecin a domicile Fes,SOS Médecin a domicile Rabat,SOS Médecin a domicile Agadir,SOS Médecins à domicile Tanger,SOS Médecin a domicile Marrakech"
        />
        <meta
          name="description"
          content="médecin a domicile, dans tous les villes de maroc"
        />
        <meta property="og:title" content="médecin a domicile - Omnidoc" />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/medecin-a-domicile"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="médecin a domicile, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="médecin a domicile" />
      </Head>
      <div className={styles._medecineadomicile_compo}>
        <div className={styles._medecineadomicile}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._medecineadomicile_title}>
            <h1 ref={medcineadomicileTitle}>Medecin À Domicile</h1>
          </div>
        </div>

        <div className={styles._medecineadomicile_content}>
          <div className={styles._medecineadomicile_content_each}>
            <div>
              <h4>MEDECINE D&apos;URGENCE</h4>
            </div>
            <p>Traumatologie et soins intensifs</p>
            <p>Soins aux personnes âgées</p>
            <p>Services communautaires</p>
            <p>Diagnostic et investigation</p>
            <p>Médical et chirurgical</p>
            <p>Spécialiste en réadaptation en santé mentale</p>
            <p>Service de soutien</p>
          </div>
          <div className={styles._medecineadomicile_content_each}>
            <div>
              <h4>MEDECINE DE SPECIALITE</h4>
            </div>
            <p>Addictologie</p>
            <p>Allergologie</p>
            <p>Anesthésie-réanimation</p>
            <p>Biologie médicale</p>
            <p>Dermatologie et vénérologie</p>
            <p>Génétique Médicale, Médecine du travail</p>
            <p>Hématologie, Médecine cardiovasculaire</p>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default MedecinADomicile;
