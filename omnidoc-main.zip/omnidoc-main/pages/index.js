import Head from "next/head";
import dynamic from "next/dynamic";
import { Suspense } from "react";
const HomeBlogs = dynamic(() => import("../components/HomeBlogs"));
const ContactBooking = dynamic(() => import("../components/Contact_booking"));
const FactsAndNumbers = dynamic(() => import("../components/FactsAndNumbers"));
const Features = dynamic(() => import("../components/Features"));
const Hero = dynamic(() => import("../components/Hero"));
const SubHero = dynamic(() => import("../components/SubHero"));
const Services = dynamic(() => import("../components/Services"));
const Testimonial = dynamic(() => import("../components/Testimonial"));
const WhyChoosingUs = dynamic(() => import("../components/WhyChoosingUs"));
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
export default function Home({ styles, blogs }) {
  return (
    <div className={styles.container}>
      <Head>
        <title>
          Médecins Sos Casablanca - Omnidoc santé, Appeler le 0627555555
        </title>
        <meta
          property="og:title"
          content="Médecins Sos Casablanca - Omnidoc santé, Appeler le 0627555555"
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.omnidoc.ma/" />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="Omnidoc Santé est une société d’assistance médicale. Médecin à domicile, Analyses à domicile, prélèvement à domicile, test PCR à domicile..."
        />
        <meta name="twitter:card" content="summary" />
        <meta
          name="twitter:text:title"
          content="Accueil - Médecins Sos Casablanca"
        />
        <meta
          name="description"
          content="Omnidoc Santé est une société d’assistance médicale. Médecin à domicile, Analyses à domicile, prélèvement à domicile, test PCR à domicile..."
        />
        <link
          href="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
          rel="icon"
        />
        <meta
          name="keywords"
          content="sos medecin,sos médecins, sos soins agadir, sos medecin rabat,sos medecin tanger, sos medecin casablanca, medecin sos casablanca, sos casablanca, sos medecin centre villesos medecin ain chok sos medecin bernoussi, sos medecin ain sbaa, sos medecin hay mohammadi, sos medecin maarif, sos medecin mohammadia, sos medecin fes, sos médecin bouskoura, médecin à domicile, médecin à domicile casablanca, medecin a domicile casablanca, médecin à domicile rabat,médecin à domicile tanger, médecin à domicile meknès,"
        />
      </Head>
      <Suspense>
        <Hero styles={styles} />
        <SubHero styles={styles} />
        <FactsAndNumbers styles={styles} />
        <Features styles={styles} />
        <WhyChoosingUs styles={styles} />
        <Services styles={styles} />
        <Testimonial styles={styles} />
        <ContactBooking styles={styles} />
        <HomeBlogs styles={styles} blogs={blogs} />
        <Newsletter styles={styles} />
        <Footer />
      </Suspense>
    </div>
  );
}

export const getServerSideProps = async (context) => {
  const query = encodeURIComponent(`*[ _type == "blog"][0...6]`);
  const url = `https://n5003uz7.api.sanity.io/v1/data/query/production?query=${query}`;
  const result = await fetch(url).then((res) => res.json());
  if (!result) {
    return {
      noblogs: true,
    };
  }
  return {
    props: {
      blogs: result.result,
    },
  };
};
