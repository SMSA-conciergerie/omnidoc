import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
import { BsShieldCheck } from "react-icons/bs";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function ContreVisite({ styles }) {
  gsap.registerPlugin(SplitText);
  const contreVisiteTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(contreVisiteTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(contreVisiteTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>CONTRE VISITE - Omnidoc santé </title>
        <link href="https://www.omnidoc.ma/contre-visite" rel="canonical" />
        <meta
          name="keywords"
          content="test PCR maroc,test PCR Fes,Ambulance Rabat,test PCR Agadir,test PCR Tanger,test PCR Marrakech,test PCR Casablanca "
        />
        <meta
          name="description"
          content="CONTRE VISITE, dans tous les villes de maroc"
        />
        <meta property="og:title" content="CONTRE VISITE - Omnidoc" />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/contre-visite"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="CONTRE VISITE, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="CONTRE VISITE" />
      </Head>
      <div className={styles._contreVisite_contreVisite_compo}>
        <div className={styles._contreVisite}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._contreVisite_title}>
            <h1 ref={contreVisiteTitle}>Contre Visite.</h1>
          </div>
        </div>
        <div className={styles._contreVisite_content}>
          <div className={styles._contreVisite_content_each}>
            <div>
              <span>
                <BsShieldCheck />
              </span>
            </div>
            <div>
              <p>
                Nous assurons une contre-visite médicale au domicile d'un
                salarié par une équipe de médecins spécialistes dans la médecine
                du travail afin de contrôler l'incapacité de travail pour
                raisons médicales, non de porter un jugement sur la nature de
                l'affection.
              </p>
            </div>
          </div>
          <div className={styles._contreVisite_content_each}>
            <div>
              <span>
                <BsShieldCheck />
              </span>
            </div>
            <div>
              <p>
                Le médecin contrôleur se présente et annonce qu'il a reçu le
                mandat d'effectuer une contre visite médicale pour le compte de
                l'employeur. Le salarié a l'obligation de se soumettre au
                contrôle du médecin, qui va juger de : la validité de l'arrêt à
                l'instant du contrôle.
              </p>
            </div>
          </div>
          <div className={styles._contreVisite_content_each}>
            <div>
              <span>
                <BsShieldCheck />
              </span>
            </div>
            <div>
              <p>
                Nous nous engageons à vous envoyer sous pli fermé le rapport
                détaillé du médecin responsable de la contre-visite ainsi que
                toutes autres informations.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default ContreVisite;
