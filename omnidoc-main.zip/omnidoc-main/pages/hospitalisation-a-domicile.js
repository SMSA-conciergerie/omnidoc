import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
import { AiOutlineCheckCircle } from "react-icons/ai";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function HospitalisationHome({ styles }) {
  gsap.registerPlugin(SplitText);
  const hospitalisationHome = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(hospitalisationHome.current, {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(hospitalisationHome.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>HOSPITALISATION A DOMICILE - Omnidoc santé </title>
        <link
          href="https://www.omnidoc.ma/hospitalisation-a-domicile"
          rel="canonical"
        />
        <meta name="keywords" content="hospitalisation a domicile" />
        <meta name="description" content="hospitalisation a domicile" />
        <meta
          property="og:title"
          content="HOSPITALISATION A DOMICILE - Omnidoc santé"
        />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/hospitalisation-a-domicile"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="HOSPITALISATION A DOMICILE - Omnidoc santéANALYSES A DOMICILE, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="HOSPITALISATION A DOMICILE" />
      </Head>
      <div className={styles._hospitalisation_compo}>
        <div className={styles._hospitalisation}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._hospitalisation_title}>
            <h1 ref={hospitalisationHome}>Hospitalisation À Domicile (HAD)</h1>
          </div>
        </div>
        <div className={styles._hospitalisation_para}>
          <p>
            L&apos;HAD est en général une alternative à l&apos;hospitalisation,
            mais il s&apos;agit aussi d&apos;une bonne solution pour réduire le
            temps passé à l&apos;hôpital lorsque l&apos;hébergement n&apos;est
            plus une absolue nécessité.
          </p>
        </div>
        <div className={styles._hospitalisation_content}>
          <div className={styles._hospitalisation_content_each}>
            <div>
              <p>
                L&apos;hospitalisation à domicile consiste à apporter au
                domicile du patient, pour une durée limitée et renouvelable, les
                mêmes soins que s&apos;il se trouvait à l&apos;hôpital. .
              </p>
            </div>
          </div>
          <div className={styles._hospitalisation_content_each}>
            <div>
              <p>
                L&apos;hospitalisation à domicile consiste à apporter au
                domicile du patient, pour une longue durée, tous les matériels
                médicaux, les équipements nécessaire à l&apos;hospitalisation.
              </p>
            </div>
          </div>
          <div className={styles._hospitalisation_content_each}>
            <div>
              <p>
                Elle vise à améliorer le confort du patient en le soignant dans
                un univers familier et en évitant ou en réduisant son séjour à
                l&apos;hôpital.
              </p>
            </div>
          </div>
        </div>
        <div className={styles._hospitalisation_second}>
          <div className={styles._hospitalisation_second_para}>
            <p>
              Le patient bénéficie d&apos;une continuité des soins et d&apos;une
              coordinations des traitements médicaux et paramédicaux,{" "}
              <span>
                lesquels sont opérés par une équipe de praticiens
                pluridisciplinaires :
              </span>
            </p>
          </div>
          <div className={styles._hospitalisation_second_options}>
            <div className={styles._hospitalisation_second_options_each}>
              <span>
                <AiOutlineCheckCircle />
              </span>
              <h4>Médecins réanimateurs</h4>
            </div>
            <div className={styles._hospitalisation_second_options_each}>
              <span>
                <AiOutlineCheckCircle />
              </span>

              <h4>Infirmières / infirmiers polyvalents</h4>
            </div>
            <div className={styles._hospitalisation_second_options_each}>
              <span>
                <AiOutlineCheckCircle />
              </span>

              <h4>Aides-soignants</h4>
            </div>
            <div className={styles._hospitalisation_second_options_each}>
              <span>
                <AiOutlineCheckCircle />
              </span>

              <h4>Kinésithérapeute</h4>
            </div>
          </div>
          <div className={styles._hospitalisation_second_para}>
            <p>
              <span>
                Le tout est géré par un médecin coordinateur, ayant la mission
                d&apos;organiser les soins (en lien avec le médecin traitant et
                des praticiens spécialisés au besoin).
              </span>
            </p>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default HospitalisationHome;
