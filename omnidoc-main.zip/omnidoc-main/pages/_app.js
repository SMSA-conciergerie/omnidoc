import { useEffect, useRef, useState } from "react";
import "../styles/global.scss";
import "swiper/scss";
import "swiper/scss/pagination";
import "swiper/scss/effect-cube";
import "swiper/scss/effect-coverflow";
import styles from "../styles/Home.module.scss";
import { MdAddCall } from "react-icons/md";
import Link from "next/link";
import Head from "next/head";
function MyApp({ Component, pageProps }) {
  const curs = useRef(null);
  const [underConstruction, setunderConstruction] = useState(true);
  useEffect(() => {
    document.addEventListener("mousemove", (e) => {
      const x = e.clientX;
      const y = e.clientY;
      curs.current.style.left = x + "px";
      curs.current.style.top = y + "px";
    });

    const ProtectingSiteContent = () => {
      window.onload = function () {
        document.body.oncontextmenu = function () {
          return false;
        };
        window.addEventListener("selectstart", function (e) {
          e.preventDefault();
        });
        document.addEventListener(
          "keydown",
          function (e) {
            if (
              e.key === "s" &&
              (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)
            ) {
              e.preventDefault();
              e.stopPropagation();
            }
          },
          false
        );
      };
    };
    ProtectingSiteContent();
  }, []);

  return (
    <div>
      <Head>
        <meta charSet="UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link
          href="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
          rel="icon"
        />
      </Head>
      <div id="custom_cursor" ref={curs}></div>
      <div className="_menu_bars_global">
        <div className="_menu_bars_global_items">
          <Link href="tel:+212627555555">
            <a>
              <span>
                <MdAddCall />
              </span>
            </a>
          </Link>
        </div>
      </div>
      <Component
        underConstruction={underConstruction}
        styles={styles}
        {...pageProps}
      />
    </div>
  );
}
export default MyApp;
