import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));

function PompFunebre({ styles }) {
  gsap.registerPlugin(SplitText);
  const pompefunebreTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(pompefunebreTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(pompefunebreTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>POMPES FUNÈBRES - Omnidoc santé </title>
        <link href="https://www.omnidoc.ma/pompe-funebre" rel="canonical" />
        <meta
          name="keywords"
          content="POMPES FUNÈBRES
"
        />
        <meta
          name="description"
          content="POMPES FUNÈBRES
, dans tous les villes de maroc"
        />
        <meta
          property="og:title"
          content="POMPES FUNÈBRES
 - Omnidoc"
        />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/pompe-funebre"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="POMPES FUNÈBRES
, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta
          name="twitter:text:title"
          content="POMPES FUNÈBRES
"
        />
      </Head>
      <div className={styles._pompesfunebre_compo}>
        <div className={styles._pompesfunebre}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._pompesfunebre_title}>
            <h1 ref={pompefunebreTitle}>POMPES FUNÈBRES</h1>
          </div>
        </div>
        <div className={styles._pompesfunebre_content_titles}>
          <h2>INHUMATION- TRANSFERT DE CORPS- RECEPTION DE CORPS.</h2>
        </div>
        <div className={styles._pompesfunebre_content}>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous recevons les familles, comprenons leurs attentes et
                répondons à leurs questionnements.
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous garantissons une écoute et une disponibilité 24h/24 et 7j/7
                en présentant des conseils professionnels et adaptés.
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous proposons une solution sur mesure pour organiser les
                obsèques en adéquation avec les volontés et aspirations du
                défunt et de sa famille.
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous procédons avec rapidité et promptitude pour la constitution
                du dossier en rassemblant les pièces nécessaires et en procédant
                aux démarches administratives
              </p>
            </div>
          </div>
        </div>
        <div className={styles._pompesfunebre_content_titles}>
          <h2>INHUMATION.</h2>
        </div>
        <div className={styles._pompesfunebre_content}>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous procédons à toutes les démarches administratives pour
                l&apos;inhumation. .
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous assurons la toilette rituelle dans les conditions
                fondamentales du rite musulman.
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous garantissons le transport de corps par avion ou par route.
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous fournissons le cercueil musulman doté de plaque
                d&apos;identification funéraire et d&apos;un hublot si la
                Famille le souhaite.
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous fournissons le linceul et les articles nécessaires à la
                toilette mortuaire.
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nos fourgons mortuaires sont tous neuf avec inscription
                religieuse,
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nos chauffeurs sont expérimentés et respectueux des rites
                musulmans et de la dignité des morts
              </p>
            </div>
          </div>
          <div className={styles._pompesfunebre_content_each}>
            <div>
              <p>
                Nous procédons aux travaux de marbrerie et à la construction de
                tombes.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default PompFunebre;
