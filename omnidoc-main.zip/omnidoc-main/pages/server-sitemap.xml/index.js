//pages/server-sitemap-index.xml/index.js
import { getServerSideSitemap } from "next-sitemap";

export const getServerSideProps = async (ctx) => {
  const query = encodeURIComponent(`*[ _type == "blog"][0...6]`);
  const url = `https://n5003uz7.api.sanity.io/v1/data/query/production?query=${query}`;
  const result = await fetch(url).then((res) => res.json());
  if (!data) {
    return "https://www.omnidoc.ma/";
  } else {
    const data = result.result;
    const fields = data.map((item) => ({
      loc: `https://www.omnidoc.ma/blog/${item.slug.current}`,
      lastmod: item._createdAt,
      priority: 0.7,
      changefreq: "daily",
    }));
    return getServerSideSitemap(ctx, fields);
  }
};

export default function SitemapIndex() {}
