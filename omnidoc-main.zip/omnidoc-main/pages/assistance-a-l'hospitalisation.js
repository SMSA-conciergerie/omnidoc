import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));

function AssistanceHome({ styles }) {
  gsap.registerPlugin(SplitText);
  const assistanceTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(assistanceTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(assistanceTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>ASSISTANCE A L'HOSPITALISATION - Omnidoc santé </title>
        <link
          href="https://www.omnidoc.ma/assistance-a-l'hospitalisation"
          rel="canonical"
        />
        <meta name="keywords" content="ASSISTANCE A L'HOSPITALISATION" />
        <meta
          name="description"
          content="ASSISTANCE A L'HOSPITALISATION, dans tous les villes de maroc"
        />
        <meta
          property="og:title"
          content="ASSISTANCE A L'HOSPITALISATION - Omnidoc"
        />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/assistance-a-l'hospitalisation"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="ASSISTANCE A L'HOSPITALISATION, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta
          name="twitter:text:title"
          content="ASSISTANCE A L'HOSPITALISATION"
        />
      </Head>
      <div className={styles._assistanceHome_compo}>
        <div className={styles._assistanceHome}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._assistanceHome_title}>
            <h1 ref={assistanceTitle}>Assistance À L'hospitalisation</h1>
          </div>
        </div>
        <div className={styles._assistanceHome_compo_para}>
          <p>
            Aides pour les démarches administratives, transmission du dossier
            aux équipes médicales, gestion de votre entrée et de votre sortie.
            Nous faisons notre maximum pour votre tranquillité d’esprit et afin
            de vous faciliter la vie. Nous assurons :
          </p>
        </div>
        <div className={styles._assistanceHome_content}>
          <div className={styles._assistanceHome_content_each}>
            <div>
              <p>Admission en centre hospitalier.</p>
            </div>
          </div>
          <div className={styles._assistanceHome_content_each}>
            <div>
              <p>Assistance d&apos;admission.</p>
            </div>
          </div>
          <div className={styles._assistanceHome_content_each}>
            <div>
              <p>Suivi du dossier médical.</p>
            </div>
          </div>
        </div>
        <div className={styles._assistanceHome_content}>
          <div className={styles._assistanceHome_content_each}>
            <div>
              <p>Avance de fonds.</p>
            </div>
          </div>
          <div className={styles._assistanceHome_content_each}>
            <div>
              <p>Règlement.</p>
            </div>
          </div>
          <div className={styles._assistanceHome_content_each}>
            <div>
              <p>Facturation, etc...</p>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default AssistanceHome;
