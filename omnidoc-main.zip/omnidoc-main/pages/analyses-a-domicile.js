import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Head from "next/head";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function AnlysesHome({ styles }) {
  gsap.registerPlugin(SplitText);
  const pcrTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(pcrTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(pcrTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>ANALYSES A DOMICILE - Omnidoc santé </title>
        <link href="https://www.omnidoc.ma/pcr-a-domicile" rel="canonical" />
        <meta
          name="keywords"
          content="test PCR maroc,test PCR Fes,Ambulance Rabat,test PCR Agadir,test PCR Tanger,test PCR Marrakech,test PCR Casablanca "
        />
        <meta
          name="description"
          content="ANALYSES A DOMICILE, dans tous les villes de maroc"
        />
        <meta property="og:title" content="ANALYSES A DOMICILE - Omnidoc" />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/pcr-a-domicile"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="ANALYSES A DOMICILE, dans tous les villes de maroc"
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="ANALYSES A DOMICILE" />
      </Head>
      <div className={styles._pcr_compo}>
        <div className={styles._pcr}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._pcr_title}>
            <h1 ref={pcrTitle}>Analyses À Domicile</h1>
          </div>
        </div>
        <div className={styles._pcr_content}>
          <div className={styles._pcr_content_each}>
            <div>
              <h2>Test rapide Covid</h2>
            </div>
            <div>
              <p>
                Nos infirmiers se rendent à votre domicile pour effectuer le
                test avec tous les équipements nécessaires et vous donne le
                résultat sur place en 15 min.
              </p>
            </div>
          </div>
          <div className={styles._pcr_content_each}>
            <div>
              <h2>Analyse médicales </h2>
            </div>
            <div>
              <p>
                Nos professionnels qualifiés se dévouent chaque jour pour vous
                offrir un bilan médical irréprochable.
              </p>
            </div>
          </div>
          <div className={styles._pcr_content_each}>
            <div>
              <h2>Prélèvement PCR ou biologique à domicile </h2>
            </div>
            <div>
              <p>
                Le test PCR à domicile est le moyen le plus précis de détecter
                un cas actif de coronavirus, dans le confort de votre maison.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Newsletter styles={styles} />
        <Footer />
      </div>
    </div>
  );
}

export default AnlysesHome;
