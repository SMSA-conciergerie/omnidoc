import { useEffect, useRef } from "react";
import Head from "next/head";
import dynamic from "next/dynamic";
import gsap, { Sine } from "gsap";
import SplitText from "../utils/Split3.min";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
export default function About({ styles }) {
  gsap.registerPlugin(SplitText);
  const aproposTitle = useRef(null);
  useEffect(() => {
    const splitServ = new SplitText(aproposTitle.current, {
      type: "lines",
      linesClass: "lineChildren",
    });

    const splitParent = new SplitText(aproposTitle.current, {
      type: "lines",
      linesClass: "lineParent",
    });
    gsap.to(splitServ.lines, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      ease: Sine.easeOut,
      duration: 2,
    });
  }, []);
  return (
    <div>
      <Head>
        <title>À propos - Omnidoc santé</title>
        <meta
          name="description"
          content="à propos de Omnidoc Santé, Omnidoc Santé est une société d’assistance médicale. Médecin à domicile, Analyses à domicile, prélèvement à domicile, test PCR à domicile..."
        />
        <link href="https://www.omnidoc.ma/a-propos" rel="canonical" />
        <meta property="og:title" content="À propos - Omnidoc" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.omnidoc.ma/a-propos" />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="à propos de Omnidoc Santé, Omnidoc Santé est une société d’assistance médicale. Médecin à domicile, Analyses à domicile, prélèvement à domicile, test PCR à domicile..."
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="à-propos" />
      </Head>
      <div className={styles._about_compo}>
        <div className={styles._about}>
          <div className={styles._about_nav}>
            <Navbar />
          </div>
          <div className={styles._about_title}>
            <h1 ref={aproposTitle}>
              A Propos de <br />
              OMNIDOC.
            </h1>
          </div>
        </div>
        <div className={styles._about_content}>
          <div className={styles._about_content_child}>
            <div className={styles._about_content_text}>
              <div>
                <div>
                  <h2>
                    Qui
                    <br /> Somme
                    <br /> Nous.
                  </h2>
                </div>
                <div className={styles._about_content_text_para}>
                  <p>
                    Omnidoc santé assure le transport de malade en ambulance,
                    dans le Maroc.
                    <br /> Vous pouvez solliciter nos services à tout moment que
                    ce soit <br />
                    pour une consultation, un rendez-vous médical, une urgence,{" "}
                    <br />
                    des analyses médicales, etc.
                    <br /> Nous assurons vos déplacements sanitaires en position
                    assise, <br />
                    demi-assise ou allongée dans les meilleures conditions.
                  </p>
                </div>
              </div>
            </div>
            <div className={styles._about_content_imageHandler}>
              <div>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/aproposimage_iYrrQJ3iH.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131832283"
                  width="384"
                  height="384"
                  loading="lazy"
                  alt="omnidoc a propos"
                  title="omnidoc a propos"
                />
              </div>
              <h3>OMNIDOC</h3>
              <h4>
                Disponible 24h/24 - 7j/7
                <br />
                dans toutes
                <br /> les villes marocaines
              </h4>
            </div>
          </div>
        </div>
      </div>
      <Newsletter styles={styles} />
      <Footer />
    </div>
  );
}
