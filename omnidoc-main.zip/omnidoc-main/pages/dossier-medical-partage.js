import Head from "next/head";
import dynamic from "next/dynamic";
const Newsletter = dynamic(() => import("../components/Newsletter"));
const Footer = dynamic(() => import("../components/Footer"));
const Navbar = dynamic(() => import("../components/Navbar"));
function MedicalFolderShared({ styles }) {
  return (
    <div className={styles._dmp_compo}>
      <Head>
        <title>dossier médical partagé DMP - Omnidoc santé</title>
        <link
          href="https://www.omnidoc.ma/dossier-medical-partage"
          rel="canonical"
        />
        <meta property="og:title" content="DMP - dossier médical partagé" />
        <meta property="og:type" content="website" />
        <meta
          property="og:url"
          content="https://www.omnidoc.ma/dossier-medical-partage"
        />
        <meta
          property="og:image"
          content="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
        />
        <meta property="og:site_name" content="omnidoc" />
        <meta property="og:locale" content="fr_FR" />
        <meta
          property="og:description"
          content="omnidoc santé dmp , dossier médical partagé"
        />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:text:title" content="Accueil" />
        <meta
          name="description"
          content="omnidoc santé dmp , dossier médical partagé"
        />
        <link
          href="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
          rel="icon"
        />
        <meta
          name="keywords"
          content="dossier medical partagé, dossier médical casablanca, dossier medical partagé maroc, DMP, dmp"
        />
      </Head>
      <div className={styles._dmp}>
        <div className={styles._dmp_nav}>
          <Navbar />
        </div>
      </div>
      <div className={styles._dmp_content}>
        <div className={styles._dmp_content_main}>
          <div>
            <h1>Le Dossier Médical Partagé (DMP)</h1>
          </div>
          <div className={styles._dmp_content_main_text1}>
            <p>
              Le Dossier Médical Partagé (DMP) est un carnet de santé numérique
              qui conserve et sécurise vos informations de santé : traitements,
              résultats d&apos;examens, allergies… <br />
              Il vous permet de les partager avec les professionnels de santé de
              votre choix, qui en ont besoin pour vous soigner
            </p>
          </div>
          <div className={styles._dmp_content_main_text2}>
            Confidentiel et sécurisé, le Dossier Médical Partagé conserve
            précieusement vos informations de santé en ligne. Il vous permet de
            les partager avec votre médecin traitant et tous les professionnels
            de santé qui vous prennent en charge, même à l&apos;hôpital.
          </div>
        </div>
        <div className={styles._dmp_content_grid}>
          <div className={styles._dmp_content_grid_each}>
            <div className={styles._dmp_content_grid_each_ndImg}>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/icons/history_l1vumE2pbK.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786257"
                width="64"
                height="64"
                loading="lazy"
                alt="Le Dossier Médical Partagé Historique"
                title="Le Dossier Médical Partagé Historique"
              />
            </div>
            <div>
              <h2>Historique</h2>
            </div>
            <div>
              <p>
                Votre historique de soins des 12 derniers mois automatiquement
                alimenté par l&apos;Assurance Maladie{" "}
              </p>
            </div>
          </div>
          <div className={styles._dmp_content_grid_each}>
            <div className={styles._dmp_content_grid_each_ndImg}>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/icons/file_-OuZsUAcz.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131785125"
                width="64"
                height="64"
                loading="lazy"
                alt="Le Dossier Médical Partagé Antécédents"
                title="Le Dossier Médical Partagé Antécédents"
              />
            </div>
            <div>
              <h2>Antécédents</h2>
            </div>
            <div>
              <p>Vos antécédents médicaux (pathologie, allergies...)</p>
            </div>
          </div>
          <div className={styles._dmp_content_grid_each}>
            <div className={styles._dmp_content_grid_each_ndImg}>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/icons/contract_VuyIWGp-9.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131784727"
                width="64"
                height="64"
                loading="lazy"
                alt="Le Dossier Médical Partagé Résultats"
                title="Le Dossier Médical Partagé Résultats"
              />
            </div>
            <div>
              <h2>Résultats</h2>
            </div>
            <div>
              <p>
                Vos résultats d&apos;examens (radio, analyses biologiques...)
              </p>
            </div>
          </div>
          <div className={styles._dmp_content_grid_each}>
            <div className={styles._dmp_content_grid_each_ndImg}>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/icons/handshake__1kx4uoUX.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131785705"
                width="64"
                height="64"
                loading="lazy"
                alt="omnidoc Anticipation,Anticipation"
                title="Le Dossier Médical Partagé  Anticipation"
              />
            </div>
            <div>
              <h2>Anticipation</h2>
            </div>
            <div>
              <p>Vos directives anticipées pour votre fin de vie</p>
            </div>
          </div>
          <div className={styles._dmp_content_grid_each}>
            <div className={styles._dmp_content_grid_each_ndImg}>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/icons/search_K0Dk7KzrM.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131787158"
                width="64"
                height="64"
                loading="lazy"
                alt="omnidoc Le Dossier Médical Partagé Compte rendu, Compte rendu"
                title="Le Dossier Médical Partagé  Compte rendu"
              />
            </div>
            <div>
              <h2>Compte rendu</h2>
            </div>
            <div>
              <p>Vos comptes rendus d&apos;hospitalisations</p>
            </div>
          </div>
          <div className={styles._dmp_content_grid_each}>
            <div className={styles._dmp_content_grid_each_ndImg}>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/icons/contact_ghgUsc4Zr.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131784535"
                width="64"
                height="64"
                loading="lazy"
                alt="Le Dossier Médical Partagé En cas d'urgence"
                title="Le Dossier Médical Partagé En cas d'urgence"
              />
            </div>
            <div>
              <h2>En cas d&apos;urgence</h2>
            </div>
            <div>
              <p>
                Les coordonnées de vos proches à prévenir en cas d&apos;urgence
              </p>
            </div>
          </div>
        </div>
      </div>
      <Newsletter styles={styles} />
      <Footer />
    </div>
  );
}

export default MedicalFolderShared;
