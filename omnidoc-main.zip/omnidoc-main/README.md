Project Omnidoc.ma
built using :

- NextJs "reactjs framework"
- GSAP library for great animation
- SASS for styling
- omnidoc santé :
  offers home medical services, responding to all health concerns of Casablanca patients.
  <br/>
  In addition, beyond secure consultations and rapid diagnoses, we guarantee you a doctor-patient relationship of trust.