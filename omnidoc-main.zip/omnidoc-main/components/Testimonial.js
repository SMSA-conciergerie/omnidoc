import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, EffectCube, Pagination } from "swiper";
function Testimonial({ styles }) {
  const pagination = {
    clickable: true,
    renderBullet: function (index, className) {
      return '<span class="' + className + '">' + (index + 1) + "</span>";
    },
  };
  return (
    <section className={styles._testimonial_compo}>
      <div className={styles._testimonial}>
        <div>
          <h2>Nos témoignages</h2>
          <h4>Ce que disent nos clients</h4>
          <p>
            N&apos;hésitez pas & essayez nos services <br /> partagez votre
            opinion & votre expérience ici.
          </p>
        </div>
        <div className={`${styles._testimonial_child} Testimonial_child`}>
          <Swiper
            effect={"cube"}
            grabCursor={true}
            cubeEffect={{
              shadow: true,
              slideShadows: true,
              shadowOffset: 20,
              shadowScale: 0.94,
            }}
            autoplay={{
              delay: 2500,
            }}
            pagination={pagination}
            modules={[EffectCube, Autoplay, Pagination]}
          >
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/y_Clj07GajO.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131800298"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>Youssef</h3>
                </div>
                <div>
                  <p>
                    Service impeccable, beaucoup de professionnalisme, je
                    recommande vivement.
                  </p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/k_1UGThuykZ.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131799576"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>Kenza</h3>
                </div>
                <div>
                  <p>
                    Super équipe, merci pour tout et surtout merci à Aicha une
                    infirmière très gentille.
                  </p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/f_-u5LMiH4xm.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131799261"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>FatimaEzzahra</h3>
                </div>
                <div>
                  <p>
                    Bonjour je témoigne de votre professionnalisme, le jour de
                    l&apos;Aïd, j&apos;ai contacté OMNI DOC à 23h25 et à 23h34
                    ils étaient chez moi.
                  </p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/k_1UGThuykZ.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131799576"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>Karim B</h3>
                </div>
                <div>
                  <p>
                    Mon grand père avait besoin de point de suture, vraiment top
                    comme la chirurgie esthétique.
                  </p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/f_-u5LMiH4xm.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131799261"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>François</h3>
                </div>
                <div>
                  <p>
                    Je témoigne de votre professionnalisme lors
                    l&apos;évacuation de Agadir vers Paris. Avion top et le
                    personnel médical super gentille
                  </p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/b_GCJ2pT9t45.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131799399"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>Bety</h3>
                </div>
                <div>
                  <p>
                    Equipe très réactive, ils parlent plusieurs langues et ils
                    suivent tous les dossiers.
                  </p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/s_xXMDK2VXM.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131800063"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>Saad</h3>
                </div>
                <div>
                  <p>
                    Bravo, enfin des ambulanciers dignes de ce nom au Maroc,
                    bravo à l&apos;équipe Omni doc.
                  </p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/h_Inzr7W75b.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131799393"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>Hakim</h3>
                </div>
                <div>
                  <p>Service de l&apos;ambulance top, hygiène impeccable.</p>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className={styles._testimonial_child_each}>
                <div className={styles._testimonial_child_each_name}>
                  <span>
                    <img
                      src="https://ik.imagekit.io/b85fe6mtm/letters/f_-u5LMiH4xm.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1655131799261"
                      width="200"
                      height="200"
                      loading="lazy"
                      alt="omnidoc testimonial"
                      title="omnidoc testimonial"
                    />
                  </span>
                </div>
                <div>
                  <h3>François</h3>
                </div>
                <div>
                  <p>
                    Je témoigne de votre professionnalisme lors
                    l&apos;évacuation de Agadir vers Paris. Avion top et le
                    personnel médical super gentille.
                  </p>
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </section>
  );
}

export default Testimonial;
