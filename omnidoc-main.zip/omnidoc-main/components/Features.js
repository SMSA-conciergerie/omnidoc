import { useEffect, useRef } from "react";
import gsap, { Power4 } from "gsap";
import ScrollTrigger from "gsap/dist/ScrollTrigger";
function Features({ styles }) {
  gsap.registerPlugin(ScrollTrigger);
  const features_compo = useRef(null);
  useEffect(() => {
    const servtl = gsap.timeline({
      scrollTrigger: {
        trigger: features_compo.current,
        start: "top center",
        scrub: 1,
      },
    });
    servtl
      .fromTo(
        ".eachfeatureleft",
        {
          scale: 0,
          y: -20,
        },
        {
          scale: 1,
          y: 0,
          stagger: 0.3,
          ease: Power4.easeOut,
          duration: 0.8,
        },
        0
      )
      .fromTo(
        ".eachfeature ",
        {
          scale: 0,
          y: -20,
        },
        {
          scale: 1,
          y: 0,
          stagger: 0.3,
          ease: Power4.easeOut,
          duration: 0.8,
        },
        window.innerWidth <= 800 ? 1 : 0
      );
  }, []);
  return (
    <section className={styles._features_compo} ref={features_compo}>
      <div className={styles._features}>
        <div className={styles._features_title}>
          <h1>Notre Savoir Faire.</h1>
        </div>
        <div>
          <p>
            &quot;La véritable expertise est la forme d&apos;autorité la plus
            puissante.&quot;
          </p>
        </div>
        <div className={styles._features_child}>
          <div className={styles._features_child_left_side}>
            <div
              className={`${styles._features_child_left_side_each} eachfeatureleft`}
            >
              <div>
                <i>Médecin à domicile</i>
                <p>
                  Consultations à domicile assurées par des médecins qualifiés.
                  Pour des soins d&apos;urgence à domicile ou sur votre lieu de
                  travail, accompagnement médical vers une structure
                  hospitalière de votre choix.
                </p>
              </div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/doctor_Vno26un8S.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131784957"
                  width="100"
                  height="100"
                  loading="lazy"
                  alt="omnidoc médecin à domicile, medecin a domicile"
                />
              </span>
            </div>
            <div
              className={`${styles._features_child_left_side_each} eachfeatureleft`}
            >
              <div>
                <i>Analyses à domicile</i>
                <p>
                  Offrez-vous la sérénité d&apos;un prélèvement chez vous. Notre
                  équipe de déplace à votre domicile pour effectuer vos
                  prélèvements.
                </p>
              </div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/medical_I0d4sI_-y6.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786880"
                  width="100"
                  height="100"
                  loading="lazy"
                  alt="omnidoc Analyses à domicile, Analyses a domicile"
                />
              </span>
            </div>
            <div
              className={`${styles._features_child_left_side_each} eachfeatureleft`}
            >
              <div>
                <i>Transport ambulance</i>
                <p>
                  Les ambulanciers de notre entreprise se tiennent à votre
                  disposition 24h/24 et 7j/7. Afin de vous conduire à vos
                  rendez-vous médicaux, pour une hospitalisation ou encore pour
                  un transfert inter-hospitalier, nous nous occupons de tout.
                </p>
              </div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/ambulance_y0aQn5-jQl.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131784336"
                  width="100"
                  height="100"
                  loading="lazy"
                  alt="omnidoc Transport ambulance, Transport ambulance"
                />
              </span>
            </div>
            <div
              className={`${styles._features_child_left_side_each} eachfeatureleft`}
            >
              <div>
                <i>Hospitalisation à domicile</i>
                <p>
                  L&apos;hospitalisation à temps complet au cours de laquelle
                  les soins sont effectués au domicile de la personne est
                  assurée par les équipes OMNIDOC
                </p>
              </div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/hospital_Y9_uZiclr.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786456"
                  width="100"
                  height="100"
                  loading="lazy"
                  alt="omnidoc Hospitalisation à domicile, Hospitalisation à domicile"
                />
              </span>
            </div>
          </div>

          <div className={styles._features_child_right_side}>
            <div
              className={`${styles._features_child_right_side_each} eachfeature`}
            >
              <div>
                <i>Materiel paramédical</i>
                <p>
                  Vente et location de matériel médical aux particuliers et
                  professionnels.
                </p>
              </div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/medkit_uWjmKfHo8T.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786983"
                  width="100"
                  height="100"
                  loading="lazy"
                  alt="omnidoc Materiel paramédical, Materiel paramédical"
                />
              </span>
            </div>
            <div
              className={`${styles._features_child_right_side_each} eachfeature`}
            >
              <div>
                <i>Dossier médical partagé</i>
                <p>
                  Confidentiel et sécurisé, le Dossier Médical Partagé conserve
                  précieusement vos informations de santé en ligne.
                </p>
              </div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/folder_58nRfDhh2.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131785198"
                  width="100"
                  height="100"
                  loading="lazy"
                  alt="omnidoc Dossier médical partagé, Dossier médical partagé"
                />
              </span>
            </div>
            <div
              className={`${styles._features_child_right_side_each} eachfeature`}
            >
              <div>
                <i>Assistance à l&apos;hospitalisation</i>
                <p>
                  Nous vous proposons un accompagnement dans vos démarches, et
                  des aides avant, après et pendant votre séjour à
                  l&apos;hôpital
                </p>
              </div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/hospital_Y9_uZiclr.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786456"
                  width="100"
                  height="100"
                  loading="lazy"
                  alt="omnidoc Assistance à l'hospitalisation, Assistance à l'hospitalisation"
                />
              </span>
            </div>
            <div
              className={`${styles._features_child_right_side_each} eachfeature`}
            >
              <div>
                <i>Personnel paramédical</i>
                <p>
                  Accompagner, soigner, préparer rééduquer des patients, garder
                  des personnes âgées: voilà à quoi ressemble le quotidien de
                  nos professionnels du paramédical
                </p>
              </div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/group_QEmx4mUbS.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131785575"
                  width="100"
                  height="100"
                  loading="lazy"
                  alt="omnidoc Personnel paramédical, Personnel paramédical"
                />
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Features;
