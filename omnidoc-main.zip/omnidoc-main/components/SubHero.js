import { useEffect, useRef } from "react";
import gsap, { Power4 } from "gsap";
import ScrollTrigger from "gsap/dist/ScrollTrigger";

const SubHero = ({ styles }) => {
  gsap.registerPlugin(ScrollTrigger);
  const sub_hero_compo = useRef(null);
  useEffect(() => {
    const servtl = gsap.timeline({
      scrollTrigger: {
        trigger: sub_hero_compo.current,
        start: "top center",
        end: "bottom 66%",
        scrub: 1,
      },
    });
    servtl.fromTo(
      ".subheroeach",
      {
        opacity: 0,
        x: -20,
      },
      {
        opacity: 1,
        x: 0,
        stagger: 0.3,
        ease: Power4.easeOut,
        duration: 1,
      }
    );
  }, []);
  return (
    <section className={styles._sub_hero_compo} ref={sub_hero_compo}>
      <div className={styles._sub_hero}>
        <div className={styles._sub_hero_child}>
          <div
            className={`${styles._sub_hero_child_each} ${styles._firstOne} subheroeach`}
          >
            <span>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/medecinsqualifies__GlaCa-on.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1655131872652"
                width="200"
                height="200"
                loading="lazy"
                alt="omnidoc santé Médecins qualifiés"
                title="omnidoc santé Médecins qualifiés"
              />
            </span>
            <h3>Médecins qualifiés</h3>
            <p>
              OMNIDOC Santé
              <br />
              est une structure regroupant
              <br />
              les meilleurs médecins urgentistes
              <br />
              et
              <br />
              spécialistes à travers le royaume.
            </p>
          </div>
          <div
            className={`${styles._sub_hero_child_each} ${styles._secondOne} subheroeach`}
          >
            <span>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/intervention-rapid_qKbrqkUDo.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870349"
                width="200"
                height="200"
                loading="lazy"
                alt="omnidoc Intervention rapide, Intervention rapide"
                title="Intervention rapide"
              />
            </span>
            <h3>Intervention rapide</h3>
            <p>
              Toujours supervisé par nos médecins. Nous vous assurons tout type
              d&apos;interventions où que vous soyez (médecins, ambulance,
              personnel paramédical, etc.)
            </p>
          </div>
          <div
            className={`${styles._sub_hero_child_each} ${styles._thirdOne} subheroeach`}
          >
            <span>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/disponible_jZegc57Sx.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1655131851397"
                width="200"
                height="200"
                loading="lazy"
                alt="omnidoc santé Disponible 24/7,Disponible 24/7"
                title="Disponible 24/7"
              />
            </span>
            <h3>Disponible 24/7</h3>
            <p>
              Offrir une prise en charge rapide et efficace à tous
              <br />
              est au cœur de notre service, disponible 7j/7 et 24h/24 grâce à
              notre logiciel et application.
            </p>
          </div>
          <div
            className={`${styles._sub_hero_child_each} ${styles._fourthOne} subheroeach`}
          >
            <span>
              <img
                src="https://ik.imagekit.io/b85fe6mtm/lamedecineconnectee_q86Ok3R47.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870895"
                width="200"
                height="200"
                loading="lazy"
                alt="omnidoc santé La médecine connectée, La médecine connectée"
                title="La médecine connectée"
              />
            </span>
            <h3>La médecine connectée</h3>
            <p>
              Parlez à un médecin en vidéo 7j/j depuis votre ordinateur ou votre
              smartphone, recevez vos ordonnances, vos dossiers médicaux aux
              même endroit grâce à notre App.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SubHero;
