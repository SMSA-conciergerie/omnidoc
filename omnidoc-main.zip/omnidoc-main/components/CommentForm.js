import axios from "axios";
import { useState } from "react";

function CommentForm({ styles, _id, isDark }) {
  const [name, setName] = useState("");
  const [commentText, setCommentText] = useState("");
  const [email, setEmail] = useState("");
  const [msg, setMessage] = useState("");
  const [stars, setStars] = useState("");
  const onSubmitComments = async (e) => {
    e.preventDefault();
    try {
      const data = {
        name,
        commentText,
        _id: _id.toString(),
        email,
        stars,
      };
      await axios.post("/api/comments", data).then((res) => {
        setMessage(res.data);
        setName("");
        setCommentText("");
        setTimeout(() => {
          window.location.reload();
        }, 800);
      });
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className={styles._commentForm_compo}>
      <style jsx global>
        {`
          input::placeholder,
          textarea::placeholder,
          input[type="emai"],
          input[type="number"],
          textarea {
            color: ${isDark ? "#fff !important" : "#3b3b3b"};
          }
        `}
      </style>

      <div className={styles._commentForm_compo_child}>
        {msg.length > 0 ? (
          <div>
            <p>{msg}</p>
          </div>
        ) : (
          <form
            className={styles._commentForm_compo_child_form}
            onSubmit={onSubmitComments}
          >
            <div className={styles._commentForm_compo_child_form_title}>
              <h2>Laissez un commentaire...</h2>
            </div>
            <div>
              <p>
                Votre adresse email ne sera pas publiée. Les champs requis sont
                indiqués *{" "}
              </p>
            </div>
            <div>
              <input
                type="text"
                placeholder="Entrer votre nom *"
                name="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div>
              <input
                type="email"
                placeholder="Entrer votre email *"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div>
              <textarea
                type="text"
                placeholder="Entrer votre commentaire *"
                name="commentText"
                value={commentText}
                rows={10}
                onChange={(e) => setCommentText(e.target.value)}
                required
              />
            </div>
            <div>
              <input
                type="text"
                placeholder="Comment évalueriez-vous notre blog *"
                name="stars"
                value={stars}
                onFocus={(e) => (e.target.type = "number")}
                onChange={(e) => {
                  if (e.target.value < 1) {
                    return setStars(1);
                  } else if (e.target.value > 5) {
                    return setStars(5);
                  } else {
                    setStars(e.target.value);
                  }
                }}
                required
              />
            </div>
            <div className={styles._form_btn}>
              <input type="submit" name="submit" value="Envoyer" />
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default CommentForm;
