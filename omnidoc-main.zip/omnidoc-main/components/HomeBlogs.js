import ImageUrlBuilder from "@sanity/image-url";
import BlockContent from "@sanity/block-content-to-react";
import Link from "next/link";
import { FaBlog } from "react-icons/fa";
function HomeBlogs({ styles, blogs }) {
  const imagebuilder = ImageUrlBuilder({
    projectId: "n5003uz7",
    dataset: "production",
  });
  return (
    <div className={styles._homeBlogs}>
      <div className={styles._homeBlogs_child}>
        <div className={styles._homeBlogs_child_btnTitle}>
          <h6>
            N'hésitez pas et visitez notre blog,
            <br /> la meilleure façon d'en savoir plus sur votre santé
          </h6>
          <Link href="blog">
            <a>
              Omnidoc Blog{" "}
              <span>
                <FaBlog />
              </span>
            </a>
          </Link>
        </div>
        {blogs.map((post, i) => {
          return (
            <div className={styles._homeBlogs_child_eachPost} key={i}>
              <div className={styles._homeBlogs_child_eachPost_image}>
                <img
                  src={imagebuilder.image(post.image.asset._ref)}
                  alt={`omnidoc santé ${post.title}`}
                  title={`omnidoc santé ${post.title}`}
                  loading="lazy"
                />
              </div>
              <div className={styles._homeBlogs_child_eachPost_type}>
                <h5>Blog</h5>
              </div>
              <div className={styles._homeBlogs_child_eachPost_titleComment}>
                <h3>{post.title}</h3>
              </div>
              <div className={styles._homeBlogs_child_eachPost_bodyText}>
                <BlockContent blocks={post.body} />
              </div>
              <div className={styles._homeBlogs_child_eachPost_urlndDate}>
                <p>{post._createdAt.substring(0, 10)}</p>
              </div>
              <div className={styles._homeBlogs_child_eachPost_readMoreurl}>
                <Link href={`/blog/${post.slug.current}`}>
                  <a>Lire la suite...</a>
                </Link>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default HomeBlogs;
