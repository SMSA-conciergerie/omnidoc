import { BsBagPlusFill } from "react-icons/bs";
//bring icons from lottifiles
function FactsAndNumbers({ styles }) {
  return (
    <section className={styles._factsandnumbers_compo}>
      <div className={styles._factsandnumbers}>
        <div>
          <h2>nos chiffres & faits</h2>
          <h4>Les Chiffres sont des Faits</h4>
          <p>
            Le travail acharné ne peut être prouvé que par les statistiques,
            <br />
            les statistiques ne mentent jamais dans aucun domaine,
            <br /> laissez les chiffres parler pour vous.
          </p>
        </div>
        <div className={styles._factsandnumbers_child}>
          <div className={styles._factsandnumbers_child_each}>
            <span>
              <BsBagPlusFill />
            </span>
            <h5>+50</h5>
            <p>Ambulances</p>
          </div>
          <div className={styles._factsandnumbers_child_each}>
            <span>
              <BsBagPlusFill />
            </span>
            <h5>+240</h5>
            <p>Médecins</p>
          </div>
          <div className={styles._factsandnumbers_child_each}>
            <span>
              <BsBagPlusFill />
            </span>
            <h5>+10000</h5>
            <p>Médicaments</p>
          </div>
          <div className={styles._factsandnumbers_child_each}>
            <span>
              <BsBagPlusFill />
            </span>
            <h5>+900</h5>
            <p>Patiente heureuse</p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default FactsAndNumbers;
