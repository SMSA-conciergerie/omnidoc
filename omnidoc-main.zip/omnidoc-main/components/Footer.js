import { AiOutlineMail, AiOutlinePhone } from "react-icons/ai";
import { FiMapPin } from "react-icons/fi";
import styles from "../styles/Home.module.scss";
import Link from "next/link";
function Footer({ isDark }) {
  return (
    <div className={styles._footer_compo}>
      <div className={isDark ? styles._footerDarkTheme : styles._footer}>
        <div
          className={
            isDark ? styles._footerDarkTheme_child : styles._footer_child
          }
        >
          <div
            className={
              isDark
                ? styles._footerDarkTheme_child_text_about
                : styles._footer_child_text_about
            }
          >
            <div>
              <div>
                <h6>OMNIDOC.</h6>
              </div>
            </div>
            <div>
              <p>
                Omnidoc santé propose des services médicaux à domicile,
                répondant à tous soucis de santé de la patientèle Casablancaise.
                De plus, au-delà des consultations sécurisées et des diagnostics
                rapides nous vous garantissons une relation de confiance
                médecins-patients.
              </p>
            </div>
            <div>
              <Link href="/a-propos">
                <a>
                  <button>Lire la suite...</button>
                </a>
              </Link>
            </div>
          </div>
          <div
            className={
              isDark
                ? styles._footerDarkTheme_child_contactus
                : styles._footer_child_contactus
            }
          >
            <div>
              <h6>NOUS CONTACTER.</h6>
            </div>
            <div>
              <ul>
                <li>
                  <Link href="tel:+212522240404">
                    <a>
                      <span>
                        <AiOutlinePhone />
                      </span>
                      +212 5 22 24 04 04
                    </a>
                  </Link>
                </li>
                <li>
                  <Link href="mailto:contact@omnidoc.ma">
                    <a>
                      <span>
                        <AiOutlineMail />
                      </span>
                      contact@omnidoc.ma
                    </a>
                  </Link>
                </li>
                <li>
                  <span>
                    <FiMapPin />
                  </span>
                  Casablanca, Morocco
                </li>
              </ul>
            </div>
          </div>
          <div
            className={
              isDark
                ? styles._footerDarkTheme_child_links
                : styles._footer_child_links
            }
          >
            <div>
              <h6>LIENS RAPIDES.</h6>
            </div>
            <div>
              <ul>
                <li>
                  <Link href="/">
                    <a>Accueil</a>
                  </Link>
                </li>
                <li>
                  <Link href="/dossier-medical-partage">
                    <a>DMP</a>
                  </Link>
                </li>
                <li>
                  <Link href="/pcr-a-domicile">
                    <a>PCR à domicile</a>
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div
            className={
              isDark
                ? styles._footerDarkTheme_child_map
                : styles._footer_child_map
            }
          >
            <div>
              <h6>PLUS SUR OMNIDOC.</h6>
            </div>
            <div>
              <ul>
                <li>
                  <Link href="/politique-de-confidentialite">
                    <a>Politique de confidentialité</a>
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div
            className={
              isDark
                ? styles._footerDarkTheme_child_logoText
                : styles._footer_child_logoText
            }
          >
            <span>OMNIDOC</span>
          </div>
        </div>
        <div
          className={
            isDark
              ? styles._footerDarkTheme_child__copyRights
              : styles._footer_copyRights
          }
        >
          <p>© 2022 Omnidoc, tous droits réservés.</p>
        </div>
      </div>
    </div>
  );
}

export default Footer;
