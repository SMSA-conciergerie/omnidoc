import { useEffect, useRef } from "react";
import gsap, { Power4 } from 'gsap';
import ScrollTrigger from "gsap/dist/ScrollTrigger";
function WhyChoosingUs({ styles }) {
  gsap.registerPlugin(ScrollTrigger);
  const whychoosingus_compo = useRef(null);
  useEffect(() => {
    const whytl = gsap.timeline({
      scrollTrigger: {
        trigger: whychoosingus_compo.current,
        start: "top center",
        scrub: 1,
      },
    });
    whytl
      .fromTo(
        ".eachwhychoosing",
        {
          scale: 0,
          y: -20,
        },
        {
          scale: 1,
          y: 0,
          stagger: 0.1,
          ease: Power4.easeOut,
          duration: 0.8,
        },
        0
      )
  }, [])
  return (
    <section className={styles._whychoosingus_compo} ref={whychoosingus_compo}>
      <div className={styles._whychoosingus}>
        <div>
          <h2>nos fonctionnalités</h2>
          <h4>Pourquoi OMNIDOC</h4>
          <p>Parce que nous offrons une marque unique de soins à domicile</p>
        </div>
        <div className={styles._whychoosingus_child}>
          <div className={styles._whychoosingus_child_content}>
            <div className={`${styles._whychoosingus_child_content_each} eachwhychoosing`}>
              <p>
                Centre de régulation médicale vous accueille 24h/24 et 7j/7 pour
                assurer le suivi de votre santé.
              </p>
            </div>
            <div className={`${styles._whychoosingus_child_content_each} eachwhychoosing`}>
              <p>
                Nos médecins urgentistes se déplacent à votre domicile dans les
                plus brefs délais.
              </p>
            </div>
            <div className={`${styles._whychoosingus_child_content_each} eachwhychoosing`}>
              <p>
                Nos médecins de gardes disposent de tout le matériel nécessaire
                à la prise en charge la plus adaptée à votre cas.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
export default WhyChoosingUs;
