import { useState } from "react";
import Marquee from "react-fast-marquee";
import { AiFillCloseCircle } from "react-icons/ai";
import axios from "axios";
function ContactBooking({ styles }) {
  const [showForms, setShowForms] = useState(true);
  const [selectedType, setSelectedType] = useState("");
  const [nomprenom, setNomPrenom] = useState("");
  const [datenaissance, setDateNaissance] = useState("");
  const [tel, setTel] = useState("");
  const [mail, setMail] = useState("");
  const [raison, setRaison] = useState("");
  const [modalrendezvous, setModaleRendezVous] = useState(false);
  const [modalcontacteznous, setModaleContactezNous] = useState(false);
  //contactez-nous states
  const [nom, setNom] = useState("");
  const [prenom, setPrenom] = useState("");
  const [telcontact, setTelContact] = useState("");
  const [mailContacteznous, setMailContactezNous] = useState("");
  const [message, setMessage] = useState("");

  //rendez-vous form
  const submitRendezVous = async (e) => {
    e.preventDefault();
    var rendezVousData = {
      selected: selectedType,
      NomPrenom: nomprenom,
      Télé: tel,
      DateNaissance: datenaissance,
      Adressemail: mail,
      RaisonRendezvous: raison,
    };
    if (
      selectedType === "" ||
      nomprenom === "" ||
      tel === "" ||
      mail === "" ||
      datenaissance === "" ||
      raison === ""
    ) {
      alert("veuillez remplir tous les champs svp...");
    } else {
      await axios.post("/api/omnidocrendezvousform", rendezVousData);
      setModaleRendezVous(true);
      setSelectedType("");
      setNomPrenom("");
      setDateNaissance("");
      setTel("");
      setMail("");
      setRaison("");
    }
  };
  //contactez-nous
  const submitContactezNous = async (e) => {
    e.preventDefault();
    var contactData = {
      Nom: nom,
      Prénom: prenom,
      Télé: telcontact,
      AdresseMail: mailContacteznous,
      Message: message,
    };
    if (
      nom === "" ||
      mailContacteznous === "" ||
      telcontact === "" ||
      message === "" ||
      prenom === ""
    ) {
      alert("veuillez remplir tous les champs svp...");
    } else if (isNaN(telcontact)) {
      alert("le numéro de téléphone est invalide");
    } else {
      await axios.post("/api/omnidoccontacform", contactData);
      setModaleContactezNous(true);
      setNom(true);
      setPrenom("");
      setMailContactezNous("");
      setMessage("");
    }
  };
  //inputs target event
  const handleChangesInputs = (e, arg) => {
    arg(e.target.value);
  };
  const rendezVous = () => {
    return (
      <div className={styles._rendez_vous_modale}>
        <div className={styles._rendez_vous_modale_child}>
          <div>
            <span
              onClick={() => {
                setModaleRendezVous(false);
              }}
            >
              <AiFillCloseCircle />
            </span>
          </div>
          <div>
            <img
              src="https://ik.imagekit.io/b85fe6mtm/modalerendez-vous_bCquAfgR4.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1655131872850"
              loading="lazy"
              alt="omnidoc contact"
            />
          </div>
          <div>
            <p>
              Nous avons reçu vos informations, nous vous contacterons bientôt,
              merci.
            </p>
          </div>
        </div>
      </div>
    );
  };
  const contactezNous = () => {
    return (
      <div className={styles._rendez_vous_modale}>
        <div className={styles._rendez_vous_modale_child}>
          <div>
            <span
              onClick={() => {
                setModaleContactezNous(false);
              }}
            >
              <AiFillCloseCircle />
            </span>
          </div>
          <div>
            <img
              src="https://ik.imagekit.io/b85fe6mtm/modalerendez-vous_bCquAfgR4.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1655131872850"
              loading="lazy"
              alt="omnidoc rendez-vous"
            />
          </div>
          <div>
            <p>
              Nous avons reçu vos informations, nous vous contacterons bientôt,
              merci.
            </p>
          </div>
        </div>
      </div>
    );
  };
  return (
    <section id="demande" className={styles._contactandbooking_compo}>
      <div className={styles._contactandbooking}>
        <div className={styles._contactandbooking_header}>
          <h2>Entrer en contact</h2>
          <p>
            Omnidoc santé assure le transport de malade en ambulance, dans le
            Maroc. Vous pouvez solliciter nos services à tout moment que ce soit
            pour une consultation, un rendez-vous médical, une urgence, des
            analyses médicales, etc. Nous assurons vos déplacements sanitaires
            en position assise, demi-assise ou allongée dans les meilleures
            conditions.
          </p>
        </div>
        <div className={styles._contactandbooking_child}>
          <div className={styles._contactandbooking_child_btns}>
            <div>
              <button onClick={() => setShowForms(true)}>
                J&apos;ai besoin
              </button>
            </div>
            <div>
              <button onClick={() => setShowForms(false)}>
                Nous contacter
              </button>
            </div>
          </div>
          {showForms ? (
            <div className={styles._contactandbooking_child_booking}>
              {modalrendezvous ? (
                rendezVous()
              ) : (
                <form onSubmit={submitRendezVous} id="form_booking">
                  <div id="booking_id">
                    <select
                      onChange={(e) => {
                        handleChangesInputs(e, setSelectedType);
                      }}
                    >
                      <option value="">Sélectionner</option>
                      <option value="Consultationà domicile">
                        Consultationà domicile
                      </option>
                      <option value="Analyse à domicile">
                        Analyse à domicile
                      </option>
                      <option value="Test PCR à domicile">
                        Test PCR à domicile
                      </option>
                      <option value="Ambulance simple">Ambulance simple</option>
                      <option value="Ambulance medicalisée">
                        Ambulance medicalisée
                      </option>
                      <option value="Véhicul sanitaire léger">
                        Véhicul sanitaire léger
                      </option>
                      <option value="Pompe funébre">Pompe funébre</option>
                      <option value="consultation contre visite">
                        consultation contre visite
                      </option>
                      <option value="Téléconsultaion">Téléconsultaion</option>
                      <option value="Conseil médical">Conseil médical</option>
                      <option value="Faire un prélèvement à domicile">
                        Faire un prélèvement à domicile
                      </option>
                      <option value="Infirmière à domicile">
                        Infirmière à domicile
                      </option>
                      <option value="Aide soignante à domicile">
                        Aide soignante à domicile
                      </option>
                      <option value="Garde de personne âgée">
                        Garde de personne âgée
                      </option>
                    </select>
                  </div>
                  <div>
                    <input
                      onChange={(e) => {
                        handleChangesInputs(e, setNomPrenom);
                      }}
                      type="text"
                      value={nomprenom}
                      placeholder="Nom & Prénom"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Date de naissance du patient"
                      onFocus={(e) => (e.target.type = "date")}
                      onChange={(e) => {
                        handleChangesInputs(e, setDateNaissance);
                      }}
                      value={datenaissance}
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Numéro de téléphone"
                      onChange={(e) => {
                        handleChangesInputs(e, setTel);
                      }}
                      value={tel}
                    />
                  </div>
                  <div>
                    <input
                      onChange={(e) => {
                        handleChangesInputs(e, setMail);
                      }}
                      type="email"
                      placeholder="Adresse e-mail"
                      value={mail}
                    />
                  </div>
                  <textarea
                    rows={5}
                    placeholder="Raison du rendez-vous"
                    value={raison}
                    onChange={(e) => {
                      handleChangesInputs(e, setRaison);
                    }}
                  />
                  <div
                    className={
                      styles._contactandbooking_child_booking_validationBtn
                    }
                  >
                    <button type="submit">Envoyer ma demande</button>
                  </div>
                </form>
              )}
            </div>
          ) : modalcontacteznous ? (
            contactezNous()
          ) : (
            <div className={styles._contactandbooking_child_contactus}>
              <form onSubmit={submitContactezNous}>
                <div>
                  <input
                    onChange={(e) => {
                      handleChangesInputs(e, setNom);
                    }}
                    value={nom}
                    type="text"
                    placeholder="Nom"
                  />
                </div>
                <div>
                  <input
                    onChange={(e) => {
                      handleChangesInputs(e, setPrenom);
                    }}
                    type="text"
                    value={prenom}
                    placeholder="Prénom"
                  />
                </div>
                <div>
                  <input
                    onChange={(e) => {
                      handleChangesInputs(e, setTelContact);
                    }}
                    type="tel"
                    value={telcontact}
                    placeholder="Télé"
                  />
                </div>
                <div>
                  <input
                    onChange={(e) => {
                      handleChangesInputs(e, setMailContactezNous);
                    }}
                    type="email"
                    value={mailContacteznous}
                    placeholder="exemple@gmail.com"
                  />
                </div>
                <textarea
                  rows={4}
                  placeholder="Message : "
                  value={message}
                  onChange={(e) => {
                    handleChangesInputs(e, setMessage);
                  }}
                />
                <div
                  className={styles._contactandbooking_bg_contact_form}
                ></div>
                <div>
                  <button type="submit">Envoyer</button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
      <Marquee pauseOnHover={true} speed={100}>
        <div className={styles._marquee_images}>
          <img
            src="https://ik.imagekit.io/b85fe6mtm/partners/CanadianMedical_wIVzz72GVx.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131809658"
            width="180"
            height="100"
            loading="lazy"
            alt="omnidoc partenairs"
          />
        </div>
        <div className={styles._marquee_images}>
          <img
            src="https://ik.imagekit.io/b85fe6mtm/partners/Cincinnati_Lt4tsXGXV.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131809977"
            width="180"
            height="100"
            loading="lazy"
            alt="omnidoc partenairs"
          />
        </div>
        <div className={styles._marquee_images}>
          <img
            src="https://ik.imagekit.io/b85fe6mtm/partners/Partners_O9G_h0okS.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131810092"
            width="180"
            height="100"
            loading="lazy"
            alt="omnidoc partenairs"
          />
        </div>
        <div className={styles._marquee_images}>
          <img
            src="https://ik.imagekit.io/b85fe6mtm/partners/PusatPerubatan_QE3hoPb7G.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131810371"
            width="180"
            height="100"
            loading="lazy"
            alt="omnidoc partenairs"
          />
        </div>
        <div className={styles._marquee_images}>
          <img
            src="https://ik.imagekit.io/b85fe6mtm/partners/swissMedical_aBZLJ0gPe.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131810484"
            width="180"
            height="100"
            loading="lazy"
            alt="omnidoc partenairs"
          />
        </div>
      </Marquee>
    </section>
  );
}

export default ContactBooking;
