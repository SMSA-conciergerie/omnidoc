import { useState, Fragment } from "react";
import axios from "axios";
function Newsletter({ styles, isDark }) {
  const [email, setEmail] = useState("");
  const [isSucceed, SetisSucceed] = useState(false);
  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = {
        email: email,
      };
      await axios.post("/api/subscribeTonewsletter", data);
      setTimeout(() => {
        SetisSucceed(true);
      }, 1000);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className={styles._newsletter_compo}>
      <style jsx global>
        {`
          input[type="email"]::placeholder,
          input[type="email"] {
            color: ${isDark ? "#3b3b3b !important" : "#3b3b3b !important"};
          }
        `}
      </style>
      <div className={styles._newsletter_compo_child}>
        {isSucceed ? (
          <div className={styles._newsletter_compo_child_lottie}>
            <img
              src="https://ik.imagekit.io/b85fe6mtm/newslettersuccess_kwgfqI_pkE.gif?ik-sdk-version=javascript-1.4.3&updatedAt=1661695862721"
              alt="omnidoc blog newsletterF"
              loading="lazy"
              width="300"
              height="300"
            />
          </div>
        ) : (
          <Fragment>
            <div>
              <h2>Abonnez-vous à notre newsletter</h2>
              <p>
                Rejoignez notre liste d'abonnés pour recevoir les dernières
                nouvelles, mises à jour et conseils, être plus connu sur votre
                santé
              </p>
            </div>
            <form onSubmit={onSubmit}>
              <div>
                <input
                  type="email"
                  placeholder="Entrer votre email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div>
                <input type="submit" name="submit" value="S'abonner" />
              </div>
            </form>
          </Fragment>
        )}
      </div>
    </div>
  );
}

export default Newsletter;
