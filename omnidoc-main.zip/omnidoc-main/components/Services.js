import Link from "next/link";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, EffectCoverflow, Pagination } from "swiper";
import gsap from "gsap";
function Services({ styles }) {
  return (
    <section className={styles._teamspecialized_compo}>
      <div className={styles._teamspecialized}>
        <div className={styles._teamspecialized_header}>
          <h2>nos services</h2>
          <h4>Dans Quoi Nous nous Sommes Spécialisés ?</h4>
        </div>
        <div className={styles._teamspecialized_child}>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/doctor_Vno26un8S.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131784957"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="omnidoc Médecin à domicile, omnidoc Médecin a domicile"
                  title="Médecin à domicile"
                />
              </span>
            </div>
            <div>
              <h6>
                Médecin
                <br /> d'urgence
              </h6>
            </div>
            <div>
              <p>
                Consultations sos médecins à domicile
                <br />
                ou sur votre lieu
                <br />
                de travail urgences
                <br />
                24h/24
              </p>
            </div>
            <div>
              <Link href="/medecin-d'urgence">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/medical_I0d4sI_-y6.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786880"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="omnidoc Analyses à domicile"
                  title="Analyses à domicile"
                />
              </span>
            </div>
            <div>
              <h6>
                {" "}
                Analyses <br />à domicile{" "}
              </h6>
            </div>
            <div>
              <p>
                Notre équipe de déplace à votre domicile <br />
                pour effectuer vos prélèvements.
              </p>
            </div>
            <div>
              <Link href="/analyses-a-domicile">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/ambulance_y0aQn5-jQl.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131784336"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="omnidoc Transport Ambulance, Transport Ambulance"
                  title="Transport Ambulance"
                />
              </span>
            </div>
            <div>
              <h6>
                Transport <br />
                Ambulance{" "}
              </h6>
            </div>
            <div>
              <p>
                Transport avec
                <br />
                ambulance médicalisée vers la structure la plus
                <br />
                adaptée : clinique,
                <br />
                hôpital…
              </p>
            </div>
            <div>
              <Link href="/transport-ambulance">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/bed_JMKswAUGf.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131784295"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="omnidoc Hospitalisation à domicile, Hospitalisation à domicile"
                  title="Hospitalisation à domicile"
                />
              </span>
            </div>
            <div>
              <h6>
                Hospitalisation <br />à domicile
              </h6>
            </div>
            <div>
              <p>Prise en charge pluridisciplinaire des patients à domicile</p>
            </div>
            <div>
              <Link href="/hospitalisation-a-domicile">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/hospital_Y9_uZiclr.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786456"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="OMNIDOC ASSISTANCE À L'HOSPITALISATION, ASSISTANCE À L'HOSPITALISATION"
                  title="ASSISTANCE À L'HOSPITALISATION"
                />
              </span>
            </div>
            <div>
              <h6>
                ASSISTANCE <br />À L&apos;HOSPITALISATION{" "}
              </h6>
            </div>
            <div>
              <p>
                Admission en centre hospitalier, Assistance d&apos;admission,
                Suivi du dossier médical, Avance de fonds, Règlement,
                Facturation, etc...
              </p>
            </div>
            <div>
              <Link href="/assistance-a-l'hospitalisation">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/medical_I0d4sI_-y6.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786880"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="omnidoc Analyses à domicile"
                  title="Analyses à domicile"
                />
              </span>
            </div>
            <div>
              <h6>
                CONTRE
                <br /> VISITE
              </h6>
            </div>
            <div>
              <p>
                Consultation à domicile à la demande de l&apos;employeur pour
                son employé à travers une intervention d&apos;un médecin
                qualifié.
              </p>
            </div>
            <div>
              <Link href="/contre-visite">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/contract_VuyIWGp-9.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131784727"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="omnidoc test PCR à domicile, test PCR à domicile"
                  title="test PCR à domicile"
                />
              </span>
            </div>
            <div>
              <h6>test PCR à domicile</h6>
            </div>
            <div>
              <p>
                Nos infirmiers se rendent à votre domicile
                <br /> pour effectuer le test avec tous les équipements
                nécessaire et vous donne le résultat sur place en 12h.
              </p>
            </div>
            <div>
              <Link href="/analyses-a-domicile">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/medkit_uWjmKfHo8T.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131786983"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="Omnidoc Matériel paramédical, Matériel paramédical"
                  title="Matériel paramédical"
                />
              </span>
            </div>
            <div>
              <h6>
                {" "}
                Matériel
                <br /> paramédical{" "}
              </h6>
            </div>
            <div>
              <p>
                Lit médical, oxygène, extracteur d&apos;oxygène, assistant
                d&apos;oxygène, assistance respirateur, ventilation non invasive
                (VNI) seringue auto poussant, scope, monitoring, béquille,
                chaise roulante, matériel d&apos;hospitalisation à domicile,
                etc...
              </p>
            </div>
            <div>
              <Link href="/materiel-paramedical">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
          <div className={`${styles._teamspecialized_child_each} _services`}>
            <div>
              <span>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/icons/folder_58nRfDhh2.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131785198"
                  width="50"
                  height="50"
                  loading="lazy"
                  alt="omnidoc Dossier médical partagé, Dossier médical partagé"
                  title="Dossier médical partagé"
                />
              </span>
            </div>
            <div>
              <h6> Dossier médical partagé </h6>
            </div>
            <div>
              <p>
                Le Dossier Médical Partagé (DMP) est un carnet de santé
                numérique qui conserve et sécurise vos informations de santé :
                traitements, résultats d&apos;examens, allergies...
                <br />
                Il vous permet de les partager avec les professionnels de santé
                de votre choix, qui en ont besoin pour vous soigner.
              </p>
            </div>
            <div>
              <Link href="/dossier-medical-partage">
                <a>Lire la suite...</a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
export default Services;
