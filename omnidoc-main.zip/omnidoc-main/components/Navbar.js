import { useRef } from "react";
import gsap, { Power4 } from "gsap";
import SplitText from "../utils/Split3.min";
import Link from "next/link";
import { AiOutlineCloseCircle } from "react-icons/ai";
import styles from "../styles/Home.module.scss";
function Navbar() {
  gsap.registerPlugin(SplitText);
  const nav_links = useRef(null);
  const main_nav_handlers = useRef(null);
  const main_nav = useRef(null);
  const menu_bars_close = useRef(null);
  const tl = gsap.timeline({
    paused: true,
  });

  const showNav = () => {
    const splitLinks = new SplitText(".links", {
      type: "lines",
      linesClass: "lineChildren",
    });
    const splitParent = new SplitText(".links", {
      type: "lines",
      linesClass: "lineParent",
    });
    tl.to(main_nav_handlers.current, {
      opacity: 0,
      ease: Power4.easeOut,
      duration: 0.1,
    })
      .to(nav_links.current, {
        display: "flex",
        duration: 0.7,
        position: "fixed",
        top: "0%",
      })
      .set(main_nav_handlers.current.children[1], { opacity: 0, duration: 0 })
      .to(main_nav_handlers.current, {
        opacity: 1,
        ease: Power4.easeOut,
        duration: 0.2,
        color: "#fff",
      })
      .to(splitLinks.lines, {
        y: 0,
        opacity: 1,
        stagger: 0.3,
        ease: Power4.easeOut,
        duration: 0.5,
      })
      .fromTo(
        menu_bars_close.current,
        { opacity: 0 },
        {
          opacity: 1,
          y: 34,
          duration: 0.1,
        }
      );
    tl.play();
  };
  const hideNav = () => {
    tl.reverse();
  };
  return (
    <div className={styles._nav_compo}>
      <div ref={main_nav} className={styles._main_nav}>
        <div ref={main_nav_handlers} className={styles._main_nav_handlers}>
          <div className="headers">
            <Link href="/">
              <a>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/logo_aDKbsYf1Y1.png?ik-sdk-version=javascript-1.4.3&updatedAt=1655131870935"
                  width="100"
                  height="80"
                  loading="lazy"
                  alt="omnidoc logo, omnidoc"
                />
              </a>
            </Link>
          </div>
          <div onClick={() => showNav()} className={styles._menu_bars_open}>
            <div></div>
            <div></div>
            <div></div>
          </div>
          <div className="headers">
            <div className={styles._main_nav_handlers_phoneNumber}>
              <Link href="tel:+212627555555">
                <a>+212 6 27 55 55 55</a>
              </Link>
              <br />
              <Link href="tel:+212627515151">
                <a>+212 6 27 51 51 51</a>
              </Link>
            </div>
          </div>
        </div>
        <nav ref={nav_links}>
          <div
            onClick={() => {
              hideNav();
            }}
            className={styles._menu_bars_close}
            ref={menu_bars_close}
          >
            <span>
              <AiOutlineCloseCircle />
            </span>
          </div>
          <ul>
            <li className="links">
              <Link href="/">
                <a>Accueil</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/a-propos">
                <a>À Propos</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/transport-ambulance">
                <a>Transport Ambulance</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/medecin-a-domicile">
                <a>Médecin à domicile</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/medecin-d'urgence">
                <a>Médecin d'urgence</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/analyses-a-domicile">
                <a>Analyses à domicile</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/dossier-medical-partage">
                <a>Dossier médical partagé</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/contre-visite">
                <a>Contre Visite</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/pompe-funebre">
                <a>Pompes Funèbres</a>
              </Link>
            </li>
            <li className="links">
              <Link href="/blog">
                <a>Blog</a>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
}

export default Navbar;
