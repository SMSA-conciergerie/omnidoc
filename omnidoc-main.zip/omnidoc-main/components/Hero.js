import { useEffect, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, Navigation } from "swiper";
import { FaPhoneAlt } from "react-icons/fa";
import Link from "next/link";
import dynamic from "next/dynamic";
import Lottie from "lottie-web";
import PHONECALL from "../public/phonecall.json";
import Schedule from "../public/schedule.json";
import WhatsApp from "../public/whatsApp.json";
import Facebook from "../public/facebook.json";
import Instagram from "../public/instagram.json";
import Linkedin from "../public/linkedin.json";
import gsap from "gsap";
import ScrollToPlugin from "gsap/dist/ScrollToPlugin";
const Navbar = dynamic(() => import("./Navbar"));

function Hero({ styles }) {
  const Phonecallcontainer = useRef(null);
  const Schedulecontainer = useRef(null);
  const WhatsAppcontainer = useRef(null);
  const PhonecallcontainerLast = useRef(null);
  //social media
  const Facebookcontainer = useRef(null);
  const Instagramcontainer = useRef(null);
  const Linkedincontainer = useRef(null);

  gsap.registerPlugin(ScrollToPlugin);
  useEffect(() => {
    Lottie.loadAnimation({
      container: Phonecallcontainer.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: PHONECALL,
    });
    Lottie.loadAnimation({
      container: PhonecallcontainerLast.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: PHONECALL,
    });
    Lottie.loadAnimation({
      container: Schedulecontainer.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: Schedule,
    });
    Lottie.loadAnimation({
      container: WhatsAppcontainer.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: WhatsApp,
    });
    return () => {
      Lottie.destroy();
    };
  }, []);
  useEffect(() => {
    //lottie social media
    Lottie.loadAnimation({
      container: Facebookcontainer.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: Facebook,
    });
    Lottie.loadAnimation({
      container: Instagramcontainer.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: Instagram,
    });
    Lottie.loadAnimation({
      container: Linkedincontainer.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: Linkedin,
    });
  }, []);
  return (
    <div className={styles._hero_compo}>
      <Navbar />
      <div className={styles._hero}>
        <div className={styles._hero_logoText}>
          <h1>
            O<br />M<br />N<br />I<br />D<br />O<br />C
          </h1>
        </div>
        <div className={styles._hero_child}>
          <Swiper
            autoplay={{
              delay: 4000,
              disableOnInteraction: false,
            }}
            pagination={{
              clickable: true,
            }}
            navigation={true}
            modules={[Autoplay, Pagination, Navigation]}
            allowTouchMove={true}
            draggable={true}
          >
            <SwiperSlide className={styles._first_swiper}>
              <div className={styles._first_swiper_content}>
                <div>
                  <h4>SOS médecin à domicile</h4>
                </div>
                <div>
                  <p>
                    Consultations sos médecins à domicile <br />
                    ou sur votre lieu de travail urgences 24h/24.
                  </p>
                </div>
                <div className={styles._first_swiper_content_btn}>
                  <Link href="tel:+212627555555">
                    <a>
                      <button>+212 6 27 55 55 55</button>
                      <span>
                        <FaPhoneAlt />
                      </span>
                    </a>
                  </Link>
                </div>
                <div className={styles._first_swiper_content_btn}>
                  <Link href="tel:+212627515151">
                    <a>
                      <button>+212 6 27 51 51 51</button>
                      <span>
                        <FaPhoneAlt />
                      </span>
                    </a>
                  </Link>
                </div>
                <div className={styles._first_swiper_content_socialMedia}>
                  <a
                    href="https://www.facebook.com/omnidoc"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <div ref={Facebookcontainer}></div>
                  </a>
                  <a
                    href="https://www.instagram.com/omnidocsante/"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <div ref={Instagramcontainer}></div>
                  </a>
                  <a
                    href="https://www.linkedin.com/company/omnidoc-sant%C3%A9/"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <div ref={Linkedincontainer}></div>
                  </a>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide className={styles._second_swiper}>
              <div className={styles._second_swiper_content}>
                <div>
                  <h3>Ambulance Casablanca à domicile</h3>
                  <p>
                    Demandez Ambulance à votre disposition.
                    <br />
                    24h/24 et 7j/7.
                  </p>
                </div>
                <div className={styles._second_swiper_content_btns_handler}>
                  <Link href="tel:+212627555555">
                    <a>
                      <div ref={Phonecallcontainer}></div>
                    </a>
                  </Link>
                  <div
                    onClick={() => {
                      gsap.to(window, {
                        duration: 2,
                        scrollTo: "#demande",
                      });
                    }}
                    ref={Schedulecontainer}
                  ></div>
                  <a
                    href="https://api.whatsapp.com/send?phone=+212627555555&text=bienvenue"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <div ref={WhatsAppcontainer}></div>
                  </a>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide className={styles._third_swiper}>
              <div className={styles._third_swiper_content}>
                <div>
                  <h4>TEST PCR À DOMICILE</h4>
                  <p>
                    Demandez votre test pcr à domicile,
                    <br />
                    résultat granti en moins de 12 heures.
                  </p>
                </div>
                <div className={styles._third_swiper_content_call}>
                  <div className={styles._first_swiper_content_btn}>
                    <Link href="tel:+212627555555">
                      <a>
                        <button>+212 6 27 55 55 55</button>
                        <span>
                          <FaPhoneAlt />
                        </span>
                      </a>
                    </Link>
                  </div>
                  <div className={styles._first_swiper_content_btn}>
                    <Link href="tel:+212627515151">
                      <a>
                        <button>+212 6 27 51 51 51</button>
                        <span>
                          <FaPhoneAlt />
                        </span>
                      </a>
                    </Link>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </div>
  );
}

export default Hero;
