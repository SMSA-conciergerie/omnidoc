import { useEffect } from "react";
import Link from "next/link";
import styles from "../styles/Home.module.scss";
function UnderConstruction() {
  useEffect(() => {
    console.log(styles);
  }, []);
  return (
    <div className={styles._under_Construction}>
      <div className={styles._under_Construction_child}>
        <div className={styles._under_Construction_child_content}>
          <div>
            <h1>OMNIDOC.</h1>
          </div>
          <div>
            <p>
              Nous sommes désolés du dérangement,
              <br />
              Cette page est encore en construction
            </p>
          </div>
          <div className={styles._under_Construction_child_content_btn}>
            <Link href="/">
              <a>
                <button>Accueil</button>
              </a>
            </Link>
          </div>
        </div>
        <div className={styles._under_Construction_child_imageHandler}>
          <img
            src="https://ik.imagekit.io/b85fe6mtm/Under_construction_vector_N5BJX8bBk.svg?ik-sdk-version=javascript-1.4.3&updatedAt=1657910000751"
            width="500"
            height="500"
            alt="omnidoc under construction page"
            title="omnidoc under construction page"
          />
        </div>
      </div>
    </div>
  );
}

export default UnderConstruction;
