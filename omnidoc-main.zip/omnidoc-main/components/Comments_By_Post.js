import { Fragment } from "react";
import Marquee from "react-fast-marquee";
import { AiFillStar } from "react-icons/ai";
export default function Comments_By_Post({ styles, comments, isDark }) {
  return (
    <div
      className={`${styles._commentsbypost} ${
        isDark ? styles._commentsbypost_isDark : null
      }`}
    >
      <div
        className={
          isDark
            ? styles._commentsbypost_title_isDark
            : styles._commentsbypost_title
        }
      >
        <h6>Voici ce que certains de nos clients disent de notre article</h6>
      </div>
      <Marquee pauseOnHover={true} speed={50}>
        {comments?.map((cmt, i) => {
          return (
            <div className={styles._commentsbypost_content_eachPost} key={i}>
              <div>
                <img
                  src="https://ik.imagekit.io/b85fe6mtm/imgbgcontactform?ik-sdk-version=javascript-1.4.3&updatedAt=1655752934851"
                  width="100"
                  height="100"
                  alt="omnidoc santé blog commentaire"
                  title="omnidoc santé blog commentaire"
                />
              </div>
              <div className={styles._commentsbypost_content_eachPost_title}>
                <h2>{cmt.name}</h2>
              </div>
              <div
                className={styles._commentsbypost_content_eachPost_textHandler}
              >
                <p>{cmt.text}</p>
              </div>
              <div>
                {cmt.stars === 1 ? (
                  <AiFillStar />
                ) : cmt.stars === 2 ? (
                  <Fragment>
                    <AiFillStar />
                    <AiFillStar />
                  </Fragment>
                ) : cmt.stars === 3 ? (
                  <Fragment>
                    <AiFillStar />
                    <AiFillStar />
                    <AiFillStar />
                  </Fragment>
                ) : cmt.stars === 4 ? (
                  <Fragment>
                    <AiFillStar />
                    <AiFillStar />
                    <AiFillStar />
                    <AiFillStar />
                  </Fragment>
                ) : (
                  <Fragment>
                    <AiFillStar />
                    <AiFillStar />
                    <AiFillStar />
                    <AiFillStar />
                    <AiFillStar />
                  </Fragment>
                )}
              </div>
            </div>
          );
        })}
      </Marquee>
    </div>
  );
}
